import React, { useState } from 'react';
import { 
  Calendar, 
  Clock, 
  MapPin, 
  CheckCircle2, 
  AlertCircle, 
  Send,
  Phone,
  Mail,
  UserCheck
} from 'lucide-react';
import { EnquirySubmission } from '../types';

export const EnquiryForm: React.FC = () => {
  const [formData, setFormData] = useState<EnquirySubmission>({
    parentName: '',
    email: '',
    phone: '',
    studentName: '',
    currentGrade: 'Grade 6',
    applyingGrade: 'Grade 7',
    preferredVisitDate: '',
    visitSession: 'Morning Session (09:30 AM)',
    message: '',
  });

  const [errors, setErrors] = useState<Partial<Record<keyof EnquirySubmission, string>>>({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const gradeOptions = [
    'Early Years (Ages 3–4)',
    'Kindergarten (Age 5)',
    'Grade 1',
    'Grade 2',
    'Grade 3',
    'Grade 4',
    'Grade 5',
    'Grade 6',
    'Grade 7',
    'Grade 8',
    'Grade 9 (IGCSE / Pre-IB)',
    'Grade 10',
    'Grade 11 (IB Diploma / AP)',
    'Grade 12',
  ];

  const validate = (): boolean => {
    const newErrors: Partial<Record<keyof EnquirySubmission, string>> = {};

    if (!formData.parentName.trim()) {
      newErrors.parentName = 'Parent or Guardian Name is required.';
    }

    if (!formData.email.trim()) {
      newErrors.email = 'Email address is required.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please provide a valid email address.';
    }

    if (!formData.phone.trim()) {
      newErrors.phone = 'Contact phone number is required.';
    } else if (formData.phone.replace(/\D/g, '').length < 7) {
      newErrors.phone = 'Please provide a valid phone number with area code.';
    }

    if (!formData.preferredVisitDate) {
      newErrors.preferredVisitDate = 'Please select a preferred campus visit date.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);
    // Simulate real brief network delay
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
    }, 600);
  };

  const resetForm = () => {
    setFormData({
      parentName: '',
      email: '',
      phone: '',
      studentName: '',
      currentGrade: 'Grade 6',
      applyingGrade: 'Grade 7',
      preferredVisitDate: '',
      visitSession: 'Morning Session (09:30 AM)',
      message: '',
    });
    setErrors({});
    setIsSubmitted(false);
  };

  return (
    <section id="tour-enquiry" className="py-20 lg:py-28 bg-[#FAF8F3] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          
          {/* Left Column: Campus Visit Context */}
          <div className="lg:col-span-5 flex flex-col items-start text-left">
            <div className="inline-flex items-center gap-2 mb-3 text-[#8E1020] text-xs uppercase tracking-[0.2em] font-semibold">
              <span className="w-6 h-[1.5px] bg-[#C7A34A]" />
              <span>Personalized Campus Visit</span>
            </div>

            <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-[#242424] leading-tight mb-6">
              Come See What Learning Can Feel Like
            </h2>

            <p className="text-base text-[#6B6B6B] leading-relaxed mb-8">
              A prospectus can describe our standards, but nothing matches experiencing our classrooms 
              in motion. Join our Director of Admissions for an individualized campus tour tailored 
              to your family’s educational values.
            </p>

            {/* Visit Highlights */}
            <div className="space-y-4 w-full mb-10">
              <div className="flex items-start gap-3.5 p-4 rounded-xl bg-white border border-[#E8E3DA]">
                <Clock className="w-5 h-5 text-[#8E1020] shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-sm font-bold text-[#242424]">90-Minute Private Tour</h3>
                  <p className="text-xs text-[#6B6B6B] mt-0.5">Explore our STEM ateliers, arts pavilion, library pods, and athletic facilities during live instructional hours.</p>
                </div>
              </div>

              <div className="flex items-start gap-3.5 p-4 rounded-xl bg-white border border-[#E8E3DA]">
                <UserCheck className="w-5 h-5 text-[#8E1020] shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-sm font-bold text-[#242424]">Faculty & Leadership Consultation</h3>
                  <p className="text-xs text-[#6B6B6B] mt-0.5">Meet divisional deans and subject department heads to discuss curriculum alignment and university trajectories.</p>
                </div>
              </div>

              <div className="flex items-start gap-3.5 p-4 rounded-xl bg-white border border-[#E8E3DA]">
                <MapPin className="w-3.5 h-3.5 text-[#C7A34A] shrink-0 mt-1" />
                <div className="text-xs text-[#6B6B6B]">
                  <strong>Nova Crest Main Campus:</strong> 45 Crestview Boulevard, Metropolis. Dedicated visitor parking available in West Gate Lot 2.
                </div>
              </div>
            </div>

            <div className="text-xs text-[#6B6B6B] border-t border-[#E8E3DA] pt-4 w-full">
              Prefer a virtual consultation? Contact admissions directly at{' '}
              <a href="mailto:admissions@novacrest.edu" className="text-[#8E1020] font-semibold underline">
                admissions@novacrest.edu
              </a>{' '}
              or call{' '}
              <span className="font-semibold text-[#242424]">+1 (800) 555-NOVA</span>.
            </div>
          </div>

          {/* Right Column: Premium Booking Form */}
          <div className="lg:col-span-7">
            <div className="bg-white rounded-2xl p-6 sm:p-10 border border-[#E8E3DA] shadow-[0_12px_40px_rgba(36,36,36,0.06)] relative">
              
              {isSubmitted ? (
                /* Success Confirmation State */
                <div className="py-8 text-center animate-fadeIn">
                  <div className="w-16 h-16 rounded-full bg-[#FBF2F3] border-2 border-[#8E1020] text-[#8E1020] flex items-center justify-center mx-auto mb-5">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <h3 className="font-display text-2xl sm:text-3xl font-bold text-[#242424] mb-3">
                    Campus Visit Request Confirmed
                  </h3>
                  <p className="text-sm text-[#6B6B6B] max-w-md mx-auto mb-6 leading-relaxed">
                    Thank you, <strong>{formData.parentName}</strong>. Our Admissions Directorate has 
                    received your request for <strong>{formData.preferredVisitDate}</strong> ({formData.visitSession}).
                    A confirmation packet and arrival itinerary have been dispatched to <strong>{formData.email}</strong>.
                  </p>

                  <div className="bg-[#FAF8F3] p-5 rounded-xl border border-[#E8E3DA] text-xs text-left max-w-md mx-auto mb-8 space-y-2">
                    <div className="font-bold text-[#8E1020] uppercase tracking-wider text-[11px]">Appointment Summary</div>
                    <div><strong>Prospective Student:</strong> {formData.studentName || 'Learner Candidate'}</div>
                    <div><strong>Grade Applying:</strong> {formData.applyingGrade}</div>
                    <div><strong>Contact Telephone:</strong> {formData.phone}</div>
                  </div>

                  <button
                    type="button"
                    onClick={resetForm}
                    className="px-6 py-2.5 bg-[#8E1020] text-white text-xs sm:text-sm font-semibold rounded-md hover:bg-[#650A16] transition-colors"
                  >
                    Submit Another Inquiry
                  </button>
                </div>
              ) : (
                /* Form Fields */
                <form onSubmit={handleSubmit} noValidate>
                  <div className="mb-6">
                    <h3 className="font-display text-2xl font-bold text-[#242424] mb-1">
                      Request a Campus Tour
                    </h3>
                    <p className="text-xs text-[#6B6B6B]">
                      Please complete the details below. Our admissions registrar will confirm your schedule within 24 hours.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 mb-5">
                    {/* Parent Name */}
                    <div>
                      <label htmlFor="parentName" className="block text-xs font-bold text-[#242424] mb-1.5">
                        Parent / Guardian Full Name <span className="text-[#8E1020]">*</span>
                      </label>
                      <input
                        id="parentName"
                        type="text"
                        value={formData.parentName}
                        onChange={(e) => setFormData({ ...formData, parentName: e.target.value })}
                        placeholder="e.g. Katherine & David Miller"
                        className={`w-full px-4 py-2.5 rounded-lg border text-sm text-[#242424] placeholder:text-[#6B6B6B]/50 focus:outline-none focus:ring-2 focus:ring-[#8E1020] transition-colors ${
                          errors.parentName ? 'border-red-500 bg-red-50/20' : 'border-[#E8E3DA] bg-white'
                        }`}
                        aria-invalid={!!errors.parentName}
                        aria-describedby={errors.parentName ? 'parentName-error' : undefined}
                      />
                      {errors.parentName && (
                        <p id="parentName-error" className="mt-1 text-xs text-red-600 flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" />
                          {errors.parentName}
                        </p>
                      )}
                    </div>

                    {/* Email */}
                    <div>
                      <label htmlFor="email" className="block text-xs font-bold text-[#242424] mb-1.5">
                        Email Address <span className="text-[#8E1020]">*</span>
                      </label>
                      <input
                        id="email"
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        placeholder="e.g. k.miller@example.com"
                        className={`w-full px-4 py-2.5 rounded-lg border text-sm text-[#242424] placeholder:text-[#6B6B6B]/50 focus:outline-none focus:ring-2 focus:ring-[#8E1020] transition-colors ${
                          errors.email ? 'border-red-500 bg-red-50/20' : 'border-[#E8E3DA] bg-white'
                        }`}
                        aria-invalid={!!errors.email}
                        aria-describedby={errors.email ? 'email-error' : undefined}
                      />
                      {errors.email && (
                        <p id="email-error" className="mt-1 text-xs text-red-600 flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" />
                          {errors.email}
                        </p>
                      )}
                    </div>

                    {/* Phone */}
                    <div>
                      <label htmlFor="phone" className="block text-xs font-bold text-[#242424] mb-1.5">
                        Phone Number <span className="text-[#8E1020]">*</span>
                      </label>
                      <input
                        id="phone"
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        placeholder="e.g. +1 (555) 234-5678"
                        className={`w-full px-4 py-2.5 rounded-lg border text-sm text-[#242424] placeholder:text-[#6B6B6B]/50 focus:outline-none focus:ring-2 focus:ring-[#8E1020] transition-colors ${
                          errors.phone ? 'border-red-500 bg-red-50/20' : 'border-[#E8E3DA] bg-white'
                        }`}
                        aria-invalid={!!errors.phone}
                        aria-describedby={errors.phone ? 'phone-error' : undefined}
                      />
                      {errors.phone && (
                        <p id="phone-error" className="mt-1 text-xs text-red-600 flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" />
                          {errors.phone}
                        </p>
                      )}
                    </div>

                    {/* Student Name */}
                    <div>
                      <label htmlFor="studentName" className="block text-xs font-bold text-[#242424] mb-1.5">
                        Child's Name (Optional)
                      </label>
                      <input
                        id="studentName"
                        type="text"
                        value={formData.studentName}
                        onChange={(e) => setFormData({ ...formData, studentName: e.target.value })}
                        placeholder="e.g. Liam Miller"
                        className="w-full px-4 py-2.5 rounded-lg border border-[#E8E3DA] bg-white text-sm text-[#242424] placeholder:text-[#6B6B6B]/50 focus:outline-none focus:ring-2 focus:ring-[#8E1020]"
                      />
                    </div>

                    {/* Applying Grade */}
                    <div>
                      <label htmlFor="applyingGrade" className="block text-xs font-bold text-[#242424] mb-1.5">
                        Grade Applying For
                      </label>
                      <select
                        id="applyingGrade"
                        value={formData.applyingGrade}
                        onChange={(e) => setFormData({ ...formData, applyingGrade: e.target.value })}
                        className="w-full px-4 py-2.5 rounded-lg border border-[#E8E3DA] bg-white text-sm text-[#242424] focus:outline-none focus:ring-2 focus:ring-[#8E1020]"
                      >
                        {gradeOptions.map((opt) => (
                          <option key={opt} value={opt}>
                            {opt}
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Preferred Date */}
                    <div>
                      <label htmlFor="preferredVisitDate" className="block text-xs font-bold text-[#242424] mb-1.5">
                        Preferred Visit Date <span className="text-[#8E1020]">*</span>
                      </label>
                      <input
                        id="preferredVisitDate"
                        type="date"
                        min="2026-10-08"
                        value={formData.preferredVisitDate}
                        onChange={(e) => setFormData({ ...formData, preferredVisitDate: e.target.value })}
                        className={`w-full px-4 py-2.5 rounded-lg border text-sm text-[#242424] focus:outline-none focus:ring-2 focus:ring-[#8E1020] transition-colors ${
                          errors.preferredVisitDate ? 'border-red-500 bg-red-50/20' : 'border-[#E8E3DA] bg-white'
                        }`}
                        aria-invalid={!!errors.preferredVisitDate}
                        aria-describedby={errors.preferredVisitDate ? 'preferredVisitDate-error' : undefined}
                      />
                      {errors.preferredVisitDate && (
                        <p id="preferredVisitDate-error" className="mt-1 text-xs text-red-600 flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" />
                          {errors.preferredVisitDate}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Visit Time Session */}
                  <div className="mb-5">
                    <label className="block text-xs font-bold text-[#242424] mb-2">
                      Preferred Tour Session
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {['Morning Session (09:30 AM)', 'Afternoon Session (01:30 PM)'].map((session) => (
                        <label
                          key={session}
                          className={`flex items-center gap-2.5 p-3 rounded-lg border text-xs cursor-pointer transition-colors ${
                            formData.visitSession === session
                              ? 'border-[#8E1020] bg-[#FBF2F3] text-[#8E1020] font-semibold'
                              : 'border-[#E8E3DA] text-[#6B6B6B] hover:border-[#8E1020]/40'
                          }`}
                        >
                          <input
                            type="radio"
                            name="visitSession"
                            value={session}
                            checked={formData.visitSession === session}
                            onChange={() => setFormData({ ...formData, visitSession: session })}
                            className="text-[#8E1020] focus:ring-[#8E1020]"
                          />
                          <span>{session}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Message */}
                  <div className="mb-6">
                    <label htmlFor="message" className="block text-xs font-bold text-[#242424] mb-1.5">
                      Specific Inquiries or Interests (Optional)
                    </label>
                    <textarea
                      id="message"
                      rows={3}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      placeholder="e.g. We are particularly interested in the IB Diploma sciences, varsity swimming, and music scholarship requirements."
                      className="w-full px-4 py-2.5 rounded-lg border border-[#E8E3DA] bg-white text-sm text-[#242424] placeholder:text-[#6B6B6B]/50 focus:outline-none focus:ring-2 focus:ring-[#8E1020]"
                    />
                  </div>

                  {/* Submit CTA */}
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-4 px-6 bg-[#8E1020] hover:bg-[#650A16] text-white font-semibold text-sm sm:text-base rounded-lg shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2.5 cursor-pointer disabled:opacity-70"
                  >
                    {isSubmitting ? (
                      <span>Processing Request...</span>
                    ) : (
                      <>
                        <Send className="w-4 h-4 text-[#E5D09A]" />
                        <span>Request a Campus Visit</span>
                      </>
                    )}
                  </button>

                  <p className="text-[11px] text-center text-[#6B6B6B] mt-3">
                    Your personal information is kept strictly confidential in accordance with our Family Privacy Policy.
                  </p>
                </form>
              )}

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
