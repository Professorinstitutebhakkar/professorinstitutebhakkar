import React from 'react';
import { 
  Building2, 
  Compass, 
  FlaskConical, 
  Trophy, 
  Laptop 
} from 'lucide-react';

const BAND_STATS = [
  {
    icon: Building2,
    value: '12+',
    label: 'Purpose-Built Spaces',
    detail: 'Modern learning studios & hubs',
  },
  {
    icon: Compass,
    value: '40+',
    label: 'Clubs & Activities',
    detail: 'Catering to every creative spark',
  },
  {
    icon: FlaskConical,
    value: '8',
    label: 'Specialist Labs & Studios',
    detail: 'Robotics, biology, media & ceramics',
  },
  {
    icon: Trophy,
    value: '25+',
    label: 'Annual Major Events',
    detail: 'Galas, tournaments & symposiums',
  },
  {
    icon: Laptop,
    value: '100%',
    label: 'Digital Learning Ready',
    detail: 'Gigabit campus & 1:1 Apple ecosystem',
  },
];

export const BurgundyStatsBand: React.FC = () => {
  return (
    <section 
      className="relative bg-[#650A16] text-[#FAF8F3] py-16 lg:py-20 overflow-hidden border-y border-[#8E1020]"
      aria-label="Campus Facilities and Activities at a Glance"
    >
      {/* Subtle geometric line pattern in CSS */}
      <div 
        className="absolute inset-0 pointer-events-none opacity-5"
        style={{
          backgroundImage: `repeating-linear-gradient(45deg, #FAF8F3 0, #FAF8F3 1px, transparent 0, transparent 40px)`
        }}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-8 lg:gap-6 text-center">
          {BAND_STATS.map((item, index) => {
            const Icon = item.icon;
            return (
              <div 
                key={index}
                className="flex flex-col items-center group p-3 rounded-lg hover:bg-white/5 transition-colors"
              >
                {/* Gold/White Icon */}
                <div className="w-12 h-12 rounded-full bg-[#8E1020]/60 border border-[#C7A34A]/50 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                  <Icon className="w-5 h-5 text-[#E5D09A]" />
                </div>

                {/* Metric Value */}
                <div className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-white tracking-tight tabular-nums mb-1">
                  {item.value}
                </div>

                {/* Label */}
                <div className="text-sm font-semibold text-[#E5D09A] mb-1 leading-snug">
                  {item.label}
                </div>

                {/* Detail */}
                <div className="text-xs text-[#FAF8F3]/70 font-light">
                  {item.detail}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
