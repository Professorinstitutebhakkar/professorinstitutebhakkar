import React, { useState } from 'react';
import { Search, X, ArrowRight, BookOpen, Compass, Calendar, MapPin } from 'lucide-react';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (href: string) => void;
}

interface SearchIndexItem {
  title: string;
  category: string;
  snippet: string;
  href: string;
}

const SEARCH_DATABASE: SearchIndexItem[] = [
  {
    title: 'Early Years Foundation (Ages 3–5)',
    category: 'Academics',
    snippet: 'Reggio-Emilia inquiry-based early childhood education and bilingual immersion.',
    href: '#academics',
  },
  {
    title: 'Primary School (Grades 1–5)',
    category: 'Academics',
    snippet: 'International Primary Curriculum (IPC), foundational literacy, and conceptual mathematics.',
    href: '#academics',
  },
  {
    title: 'Middle School (Grades 6–8)',
    category: 'Academics',
    snippet: 'Analytical inquiry, design thinking, robotics, and adolescent leadership advisory.',
    href: '#academics',
  },
  {
    title: 'Senior School (Grades 9–10)',
    category: 'Academics',
    snippet: 'IGCSE and pre-IB curriculum frameworks with specialized laboratory sciences.',
    href: '#academics',
  },
  {
    title: 'Pre-University & IB Diploma (Grades 11–12)',
    category: 'Academics',
    snippet: 'International Baccalaureate (IB DP) and Advanced Placement honors with 100% tertiary placement.',
    href: '#academics',
  },
  {
    title: 'Admissions 2026–2027 Guidelines',
    category: 'Admissions',
    snippet: 'Application deadlines, family consultations, assessment days, and rolling decisions.',
    href: '#admissions',
  },
  {
    title: 'Campus Tour Booking',
    category: 'Admissions',
    snippet: 'Schedule a private 90-minute walkthrough of our 24-acre parkland campus.',
    href: '#tour-enquiry',
  },
  {
    title: 'Tuition, Scholarships & Grants',
    category: 'Admissions',
    snippet: 'Transparent tuition breakdown, sibling discounts, and merit academic awards.',
    href: '#tour-enquiry',
  },
  {
    title: 'Robotics & STEM Laboratories',
    category: 'Facilities',
    snippet: 'University-grade chemistry, biology, physics, and autonomous robotics ateliers.',
    href: '#experience',
  },
  {
    title: 'Performing Arts Auditorium & Orchestra',
    category: 'Campus Life',
    snippet: '650-seat acoustically tuned concert hall, jazz ensembles, and theatrical productions.',
    href: '#campus-life',
  },
  {
    title: 'Competitive Varsity Athletics',
    category: 'Campus Life',
    snippet: 'Olympic pool, 400m synthetic track, soccer pitch, and 14 regional championship titles.',
    href: '#campus-life',
  },
  {
    title: 'Our Founding Philosophy & Head of School',
    category: 'About',
    snippet: 'Dr. Margaret Sterling on educating curious, ethical, and courageous leaders.',
    href: '#story',
  },
];

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  onNavigate,
}) => {
  const [query, setQuery] = useState('');

  if (!isOpen) return null;

  const results = query.trim() === ''
    ? SEARCH_DATABASE.slice(0, 5)
    : SEARCH_DATABASE.filter(
        (item) =>
          item.title.toLowerCase().includes(query.toLowerCase()) ||
          item.snippet.toLowerCase().includes(query.toLowerCase()) ||
          item.category.toLowerCase().includes(query.toLowerCase())
      );

  const handleSelect = (href: string) => {
    onClose();
    onNavigate(href);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center pt-20 px-4 bg-black/60 backdrop-blur-xs animate-fadeIn"
      role="dialog"
      aria-modal="true"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-2xl max-w-xl w-full border border-[#E8E3DA] shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="flex items-center px-5 py-4 border-b border-[#E8E3DA] bg-[#FAF8F3]">
          <Search className="w-5 h-5 text-[#8E1020] mr-3 shrink-0" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search programs, admissions, sports, facilities..."
            className="w-full bg-transparent text-sm sm:text-base text-[#242424] placeholder:text-[#6B6B6B] focus:outline-none"
            autoFocus
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="text-xs text-[#6B6B6B] hover:text-[#242424] px-2 py-1"
            >
              Clear
            </button>
          )}
          <button
            onClick={onClose}
            className="p-1 rounded-md text-[#6B6B6B] hover:text-[#242424] ml-2"
            aria-label="Close search"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Results List */}
        <div className="max-h-[60vh] overflow-y-auto p-4 space-y-2">
          <div className="text-[11px] font-bold uppercase tracking-wider text-[#8E1020] px-2 mb-2">
            {query.trim() === '' ? 'Popular Queries' : `Search Results (${results.length})`}
          </div>

          {results.length === 0 ? (
            <div className="py-8 text-center text-xs text-[#6B6B6B]">
              No matching pages found for "{query}". Try searching "Admissions", "STEM", or "Athletics".
            </div>
          ) : (
            results.map((item, index) => (
              <button
                key={index}
                onClick={() => handleSelect(item.href)}
                className="w-full text-left p-3 rounded-xl hover:bg-[#FBF2F3] transition-colors border border-transparent hover:border-[#8E1020]/20 flex items-start justify-between group cursor-pointer"
              >
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-white text-[#8E1020] border border-[#E8E3DA]">
                      {item.category}
                    </span>
                    <span className="text-sm font-bold text-[#242424] group-hover:text-[#8E1020] transition-colors">
                      {item.title}
                    </span>
                  </div>
                  <p className="text-xs text-[#6B6B6B] line-clamp-1">{item.snippet}</p>
                </div>
                <ArrowRight className="w-4 h-4 text-[#8E1020] opacity-0 group-hover:opacity-100 transform group-hover:translate-x-1 transition-all shrink-0 mt-2 ml-2" />
              </button>
            ))
          )}
        </div>

        {/* Footer Hint */}
        <div className="px-5 py-3 bg-[#FAF8F3] border-t border-[#E8E3DA] text-[11px] text-[#6B6B6B] flex items-center justify-between">
          <span>Press ESC or click outside to dismiss</span>
          <span className="font-semibold text-[#8E1020]">Nova Crest Search Directory</span>
        </div>
      </div>
    </div>
  );
};
