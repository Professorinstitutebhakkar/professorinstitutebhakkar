import React, { useState, useEffect } from 'react';
import { 
  Phone, 
  Mail, 
  MapPin, 
  Search, 
  Menu, 
  X, 
  ChevronRight, 
  Calendar,
  Lock,
  Globe2,
  Instagram,
  Facebook,
  Linkedin,
  Youtube
} from 'lucide-react';
import { CrestLogo } from './CrestLogo';

interface HeaderProps {
  onOpenSearch: () => void;
  onBookTourClick: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenSearch, onBookTourClick }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 40);

      // Section scroll spy
      const sections = ['home', 'story', 'academics', 'why-us', 'campus-life', 'experience', 'news', 'admissions'];
      const scrollPosition = window.scrollY + 200;

      for (const section of sections) {
        const el = document.getElementById(section);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'About', href: '#story', id: 'story' },
    { label: 'Academics', href: '#academics', id: 'academics' },
    { label: 'Why Nova Crest', href: '#why-us', id: 'why-us' },
    { label: 'Campus Life', href: '#campus-life', id: 'campus-life' },
    { label: 'Experience', href: '#experience', id: 'experience' },
    { label: 'Journal', href: '#news', id: 'news' },
    { label: 'Admissions', href: '#admissions', id: 'admissions' },
  ];

  const handleNavClick = (href: string) => {
    setMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      <header className="sticky top-0 z-40 w-full bg-white transition-all duration-300">
        {/* Top Utility Bar */}
        <div className="bg-[#650A16] text-[#FAF8F3] text-xs font-medium border-b border-[#8E1020]/40">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2 flex items-center justify-between">
            {/* Left Contact Details */}
            <div className="flex items-center space-x-6">
              <a
                href="tel:+18005556682"
                className="flex items-center gap-1.5 hover:text-[#E5D09A] transition-colors"
                title="Call Admissions Office"
              >
                <Phone className="w-3.5 h-3.5 text-[#C7A34A]" />
                <span className="tabular-nums">+1 (800) 555-NOVA</span>
              </a>
              <a
                href="mailto:admissions@novacrest.edu"
                className="hidden md:flex items-center gap-1.5 hover:text-[#E5D09A] transition-colors"
                title="Email Admissions"
              >
                <Mail className="w-3.5 h-3.5 text-[#C7A34A]" />
                <span>admissions@novacrest.edu</span>
              </a>
              <span className="hidden lg:flex items-center gap-1.5 text-[#FAF8F3]/80">
                <MapPin className="w-3.5 h-3.5 text-[#C7A34A]" />
                <span>45 Crestview Blvd, Metropolis</span>
              </span>
            </div>

            {/* Right Portals & Social */}
            <div className="flex items-center space-x-5 text-xs">
              <a
                href="#portal"
                onClick={(e) => {
                  e.preventDefault();
                  alert('Parent Portal: Logging in to the secure Nova Crest Family Gateway (Veritas SIS).');
                }}
                className="flex items-center gap-1 hover:text-[#E5D09A] transition-colors"
              >
                <Lock className="w-3 h-3 text-[#C7A34A]" />
                <span>Parent Portal</span>
              </a>
              <a
                href="#careers"
                onClick={(e) => {
                  e.preventDefault();
                  alert('Careers at Nova Crest: We are welcoming applications for Faculty & Leadership roles for Academic Year 2026–2027.');
                }}
                className="hidden sm:inline hover:text-[#E5D09A] transition-colors"
              >
                Careers
              </a>
              <a
                href="#alumni"
                onClick={(e) => {
                  e.preventDefault();
                  alert('Alumni Network: Welcome Nova Crest Alumni. Register for the 2026 Global Homecoming Gala.');
                }}
                className="hidden sm:inline hover:text-[#E5D09A] transition-colors"
              >
                Alumni
              </a>

              <div className="hidden md:flex items-center space-x-2 pl-2 border-l border-[#8E1020]/60">
                <a href="https://instagram.com" target="_blank" rel="noreferrer" className="text-white/70 hover:text-[#C7A34A] transition-colors p-0.5" aria-label="Instagram">
                  <Instagram className="w-3.5 h-3.5" />
                </a>
                <a href="https://facebook.com" target="_blank" rel="noreferrer" className="text-white/70 hover:text-[#C7A34A] transition-colors p-0.5" aria-label="Facebook">
                  <Facebook className="w-3.5 h-3.5" />
                </a>
                <a href="https://linkedin.com" target="_blank" rel="noreferrer" className="text-white/70 hover:text-[#C7A34A] transition-colors p-0.5" aria-label="LinkedIn">
                  <Linkedin className="w-3.5 h-3.5" />
                </a>
                <a href="https://youtube.com" target="_blank" rel="noreferrer" className="text-white/70 hover:text-[#C7A34A] transition-colors p-0.5" aria-label="YouTube">
                  <Youtube className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Main Navigation Bar */}
        <div
          className={`border-b border-[#E8E3DA] transition-shadow duration-300 ${
            isScrolled ? 'shadow-[0_4px_20px_rgba(101,10,22,0.06)]' : ''
          }`}
        >
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-20">
              {/* Brand Logo */}
              <a
                href="#home"
                onClick={(e) => {
                  e.preventDefault();
                  handleNavClick('#home');
                }}
                className="focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8E1020] rounded-sm transition-opacity hover:opacity-95"
                aria-label="Nova Crest International Academy Home"
              >
                <CrestLogo />
              </a>

              {/* Desktop Navigation Links */}
              <nav className="hidden lg:flex items-center space-x-7" aria-label="Main Navigation">
                {navLinks.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => handleNavClick(item.href)}
                    className={`relative text-[14px] font-medium tracking-wide transition-colors py-2 group cursor-pointer ${
                      activeSection === item.id
                        ? 'text-[#8E1020] font-semibold'
                        : 'text-[#242424] hover:text-[#8E1020]'
                    }`}
                  >
                    {item.label}
                    <span
                      className={`absolute bottom-0 left-0 w-full h-[2px] bg-[#8E1020] transform origin-left transition-transform duration-300 ${
                        activeSection === item.id
                          ? 'scale-x-100'
                          : 'scale-x-0 group-hover:scale-x-100'
                      }`}
                    />
                  </button>
                ))}
              </nav>

              {/* Right CTA Actions */}
              <div className="flex items-center space-x-3">
                {/* Search Button */}
                <button
                  type="button"
                  onClick={onOpenSearch}
                  className="p-2.5 text-[#242424] hover:text-[#8E1020] hover:bg-[#FBF2F3] rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-[#8E1020]"
                  aria-label="Search courses, faculty, and campus directory"
                  title="Search site"
                >
                  <Search className="w-5 h-5" />
                </button>

                {/* Primary CTA: Book Tour */}
                <button
                  type="button"
                  onClick={onBookTourClick}
                  className="hidden sm:inline-flex items-center justify-center gap-2 px-5 py-2.5 text-xs sm:text-sm font-semibold text-white bg-[#8E1020] hover:bg-[#650A16] active:bg-[#A51D2D] rounded-md transition-all shadow-sm hover:shadow-md cursor-pointer whitespace-nowrap focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-[#8E1020]"
                >
                  <Calendar className="w-4 h-4 text-[#E5D09A]" />
                  <span>Book a Campus Tour</span>
                </button>

                {/* Mobile Menu Toggle */}
                <button
                  type="button"
                  onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                  className="lg:hidden p-2 text-[#242424] hover:text-[#8E1020] focus:outline-none focus:ring-2 focus:ring-[#8E1020] rounded-md"
                  aria-expanded={mobileMenuOpen}
                  aria-label="Toggle Navigation Menu"
                >
                  {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
                </button>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Slide-down Navigation Panel */}
      {mobileMenuOpen && (
        <div className="lg:hidden fixed inset-0 top-[112px] z-50 bg-[#242424]/60 backdrop-blur-xs animate-fadeIn">
          <div className="bg-white max-h-[85vh] overflow-y-auto border-b border-[#E8E3DA] p-6 shadow-2xl">
            <div className="flex flex-col space-y-4">
              <span className="text-xs uppercase tracking-widest text-[#8E1020] font-semibold border-b border-[#E8E3DA] pb-2">
                Navigation Menu
              </span>
              {navLinks.map((item) => (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.href)}
                  className="flex items-center justify-between text-left py-2.5 text-base font-medium text-[#242424] hover:text-[#8E1020] border-b border-[#FAF8F3]"
                >
                  <span>{item.label}</span>
                  <ChevronRight className="w-4 h-4 text-[#8E1020]" />
                </button>
              ))}

              <div className="pt-4 flex flex-col gap-3">
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onBookTourClick();
                  }}
                  className="w-full py-3 px-4 bg-[#8E1020] text-white rounded-md font-semibold text-sm flex items-center justify-center gap-2 shadow-sm"
                >
                  <Calendar className="w-4 h-4 text-[#E5D09A]" />
                  Book a Campus Tour
                </button>

                <div className="bg-[#FAF8F3] p-4 rounded-md border border-[#E8E3DA] text-xs space-y-2 mt-2">
                  <div className="font-semibold text-[#8E1020]">Nova Crest Admissions Office</div>
                  <div className="flex items-center gap-2 text-[#6B6B6B]">
                    <Phone className="w-3.5 h-3.5 text-[#C7A34A]" />
                    <span>+1 (800) 555-NOVA (Mon–Fri, 8am–5pm)</span>
                  </div>
                  <div className="flex items-center gap-2 text-[#6B6B6B]">
                    <Mail className="w-3.5 h-3.5 text-[#C7A34A]" />
                    <span>admissions@novacrest.edu</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
