import React from 'react';
import { ArrowRight, Calendar, Sparkles, CheckCircle } from 'lucide-react';

interface AdmissionsCTAProps {
  onStartApplication: () => void;
  onBookCampusTour: () => void;
}

export const AdmissionsCTA: React.FC<AdmissionsCTAProps> = ({
  onStartApplication,
  onBookCampusTour,
}) => {
  return (
    <section 
      id="admissions" 
      className="relative bg-[#650A16] text-[#FAF8F3] py-20 lg:py-28 overflow-hidden border-t border-[#8E1020]"
    >
      {/* Background subtle geometric texture */}
      <div 
        className="absolute inset-0 pointer-events-none opacity-10"
        style={{
          backgroundImage: `radial-gradient(#C7A34A 1.5px, transparent 1.5px)`,
          backgroundSize: '32px 32px'
        }}
      />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
        
        {/* Admissions Open Pill */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#8E1020] text-[#E5D09A] border border-[#C7A34A]/40 text-xs font-semibold uppercase tracking-wider mb-8 shadow-sm">
          <Sparkles className="w-3.5 h-3.5 text-[#C7A34A]" />
          <span>Admissions for the 2026–27 academic year are now open</span>
        </div>

        {/* Main Heading */}
        <h2 className="font-display text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-white tracking-tight leading-[1.1] mb-6">
          Your Child's Next Chapter Starts Here.
        </h2>

        {/* Supporting Copy */}
        <p className="text-base sm:text-xl text-[#FAF8F3]/90 max-w-2xl mx-auto leading-relaxed mb-10 font-light">
          Discover a school where academic ambition, character, creativity, and belonging grow together. 
          Take the first step toward an exceptional educational journey.
        </p>

        {/* Dual CTA Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 max-w-md mx-auto mb-10">
          <button
            type="button"
            onClick={onStartApplication}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-8 py-4 bg-[#C7A34A] hover:bg-[#E5D09A] text-[#242424] font-bold text-sm sm:text-base rounded-md shadow-lg hover:shadow-xl transition-all cursor-pointer group"
          >
            <span>Start an Application</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>

          <button
            type="button"
            onClick={onBookCampusTour}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-7 py-4 bg-transparent border-2 border-white/80 hover:bg-white hover:text-[#650A16] text-white font-bold text-sm sm:text-base rounded-md transition-all cursor-pointer"
          >
            <Calendar className="w-4 h-4" />
            <span>Book a Campus Tour</span>
          </button>
        </div>

        {/* Assurance Line */}
        <div className="flex flex-wrap items-center justify-center gap-6 text-xs text-[#FAF8F3]/75">
          <span className="flex items-center gap-1.5">
            <CheckCircle className="w-3.5 h-3.5 text-[#C7A34A]" />
            Rolling Application Review
          </span>
          <span className="flex items-center gap-1.5">
            <CheckCircle className="w-3.5 h-3.5 text-[#C7A34A]" />
            Merit Scholarship Grants Available
          </span>
          <span className="flex items-center gap-1.5">
            <CheckCircle className="w-3.5 h-3.5 text-[#C7A34A]" />
            Personalized Family Consultations
          </span>
        </div>

      </div>
    </section>
  );
};
