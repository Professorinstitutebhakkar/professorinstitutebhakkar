import React, { useState } from 'react';
import { 
  Phone, 
  Mail, 
  MapPin, 
  Clock, 
  Send, 
  Check, 
  Instagram, 
  Facebook, 
  Linkedin, 
  Youtube,
  ShieldCheck,
  Award
} from 'lucide-react';
import { CrestLogo } from './CrestLogo';

export const Footer: React.FC = () => {
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterStatus, setNewsletterStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(newsletterEmail)) {
      setNewsletterStatus('error');
      return;
    }

    setNewsletterStatus('success');
    setNewsletterEmail('');
  };

  return (
    <footer className="bg-[#650A16] text-[#FAF8F3] pt-16 lg:pt-20 pb-12 border-t-2 border-[#C7A34A]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Brand Statement Row */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 pb-14 border-b border-[#8E1020]">
          <div className="lg:col-span-5">
            <CrestLogo variant="light" className="mb-4" />
            <p className="text-sm text-[#FAF8F3]/80 leading-relaxed max-w-md mt-4">
              Nova Crest International Academy is an independent co-educational college-preparatory 
              day and boarding school providing transformative academic pathways from Early Years 
              through Pre-University.
            </p>
            <div className="flex items-center gap-4 mt-6">
              <span className="text-xs uppercase tracking-widest text-[#E5D09A] font-semibold">
                Global Accreditations:
              </span>
              <div className="flex items-center gap-3 text-xs text-[#FAF8F3]/70">
                <span className="border border-[#C7A34A]/40 px-2 py-0.5 rounded">IB World School</span>
                <span className="border border-[#C7A34A]/40 px-2 py-0.5 rounded">CIS Accredited</span>
                <span className="border border-[#C7A34A]/40 px-2 py-0.5 rounded">NEASC</span>
              </div>
            </div>
          </div>

          {/* Newsletter Box in Top Row */}
          <div className="lg:col-span-7 flex flex-col justify-center">
            <div className="bg-[#8E1020]/50 p-6 rounded-xl border border-[#C7A34A]/30">
              <h3 className="font-display text-lg font-bold text-white mb-1">
                Stay Connected with Nova Crest
              </h3>
              <p className="text-xs text-[#FAF8F3]/80 mb-4">
                Receive termly gazettes, symposium invitations, and admissions calendar notifications.
              </p>

              {newsletterStatus === 'success' ? (
                <div className="flex items-center gap-2 text-xs text-[#E5D09A] bg-[#650A16] p-3 rounded-lg border border-[#C7A34A]/50 font-medium">
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span>Thank you for subscribing to the Nova Crest Gazette.</span>
                </div>
              ) : (
                <form onSubmit={handleNewsletterSubmit} className="flex flex-col sm:flex-row gap-3">
                  <input
                    type="email"
                    value={newsletterEmail}
                    onChange={(e) => {
                      setNewsletterEmail(e.target.value);
                      if (newsletterStatus === 'error') setNewsletterStatus('idle');
                    }}
                    placeholder="Enter your email address"
                    className="flex-1 px-4 py-2.5 rounded-lg bg-[#FAF8F3] text-[#242424] placeholder:text-[#6B6B6B] text-xs focus:outline-none focus:ring-2 focus:ring-[#C7A34A]"
                  />
                  <button
                    type="submit"
                    className="px-6 py-2.5 bg-[#C7A34A] hover:bg-[#E5D09A] text-[#242424] font-bold text-xs uppercase tracking-wider rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer shrink-0"
                  >
                    <span>Subscribe</span>
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </form>
              )}
              {newsletterStatus === 'error' && (
                <p className="text-xs text-red-300 mt-2">
                  Please enter a valid email address.
                </p>
              )}
            </div>
          </div>
        </div>

        {/* Multi-Column Links Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 py-12 border-b border-[#8E1020]">
          
          {/* Column 1: Explore */}
          <div>
            <h4 className="text-xs uppercase tracking-[0.18em] font-bold text-[#E5D09A] mb-4">
              Explore Nova Crest
            </h4>
            <ul className="space-y-2.5 text-xs text-[#FAF8F3]/80">
              <li><a href="#story" className="hover:text-white transition-colors">Our Founding Story</a></li>
              <li><a href="#story" className="hover:text-white transition-colors">Mission, Values & Creed</a></li>
              <li><a href="#academics" className="hover:text-white transition-colors">Curriculum Framework</a></li>
              <li><a href="#academics" className="hover:text-white transition-colors">Faculty Directory</a></li>
              <li><a href="#campus-life" className="hover:text-white transition-colors">Athletics & Performing Arts</a></li>
              <li><a href="#experience" className="hover:text-white transition-colors">Campus Map & Virtual Tour</a></li>
              <li><a href="#news" className="hover:text-white transition-colors">The Veritas Gazette</a></li>
            </ul>
          </div>

          {/* Column 2: Admissions */}
          <div>
            <h4 className="text-xs uppercase tracking-[0.18em] font-bold text-[#E5D09A] mb-4">
              Admissions & Aid
            </h4>
            <ul className="space-y-2.5 text-xs text-[#FAF8F3]/80">
              <li><a href="#tour-enquiry" className="hover:text-white transition-colors">How to Apply (2026–27)</a></li>
              <li><a href="#tour-enquiry" className="hover:text-white transition-colors">Schedule a Private Tour</a></li>
              <li><a href="#tour-enquiry" className="hover:text-white transition-colors">Tuition & Financial Grants</a></li>
              <li><a href="#tour-enquiry" className="hover:text-white transition-colors">Scholarship Examinations</a></li>
              <li><a href="#tour-enquiry" className="hover:text-white transition-colors">International Student Visas</a></li>
              <li><a href="#tour-enquiry" className="hover:text-white transition-colors">Admissions FAQs</a></li>
              <li><a href="#tour-enquiry" className="hover:text-white transition-colors">Download Academy Prospectus</a></li>
            </ul>
          </div>

          {/* Column 3: Contact & Visiting */}
          <div className="lg:col-span-2">
            <h4 className="text-xs uppercase tracking-[0.18em] font-bold text-[#E5D09A] mb-4">
              Campus Headquarters
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs text-[#FAF8F3]/80">
              <div className="space-y-3">
                <div className="flex items-start gap-2.5">
                  <MapPin className="w-4 h-4 text-[#C7A34A] shrink-0 mt-0.5" />
                  <span>45 Crestview Boulevard, University District, Metropolis 94103</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Phone className="w-4 h-4 text-[#C7A34A] shrink-0" />
                  <a href="tel:+18005556682" className="hover:text-white tabular-nums">+1 (800) 555-NOVA</a>
                </div>
                <div className="flex items-center gap-2.5">
                  <Mail className="w-4 h-4 text-[#C7A34A] shrink-0" />
                  <a href="mailto:admissions@novacrest.edu" className="hover:text-white">admissions@novacrest.edu</a>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex items-start gap-2.5">
                  <Clock className="w-4 h-4 text-[#C7A34A] shrink-0 mt-0.5" />
                  <div>
                    <div className="font-semibold text-white">Administrative Hours</div>
                    <div>Monday – Friday: 08:00 – 17:00 EST</div>
                    <div className="text-[11px] text-[#FAF8F3]/60">Closed on Academic Holidays</div>
                  </div>
                </div>

                <div className="pt-2">
                  <span className="block text-[11px] uppercase tracking-wider text-[#E5D09A] mb-2 font-semibold">
                    Follow Academy Life:
                  </span>
                  <div className="flex items-center space-x-3">
                    <a href="https://instagram.com" target="_blank" rel="noreferrer" className="w-8 h-8 rounded-full bg-[#8E1020] hover:bg-[#C7A34A] hover:text-[#242424] flex items-center justify-center transition-colors" aria-label="Nova Crest Instagram">
                      <Instagram className="w-4 h-4" />
                    </a>
                    <a href="https://facebook.com" target="_blank" rel="noreferrer" className="w-8 h-8 rounded-full bg-[#8E1020] hover:bg-[#C7A34A] hover:text-[#242424] flex items-center justify-center transition-colors" aria-label="Nova Crest Facebook">
                      <Facebook className="w-4 h-4" />
                    </a>
                    <a href="https://linkedin.com" target="_blank" rel="noreferrer" className="w-8 h-8 rounded-full bg-[#8E1020] hover:bg-[#C7A34A] hover:text-[#242424] flex items-center justify-center transition-colors" aria-label="Nova Crest LinkedIn">
                      <Linkedin className="w-4 h-4" />
                    </a>
                    <a href="https://youtube.com" target="_blank" rel="noreferrer" className="w-8 h-8 rounded-full bg-[#8E1020] hover:bg-[#C7A34A] hover:text-[#242424] flex items-center justify-center transition-colors" aria-label="Nova Crest YouTube">
                      <Youtube className="w-4 h-4" />
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Legal & Copyright Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-[#FAF8F3]/60 gap-4">
          <div>
            © 2026 Nova Crest International Academy. All rights reserved.
          </div>
          <div className="flex items-center space-x-6">
            <a href="#privacy" onClick={(e) => { e.preventDefault(); alert('Nova Crest Privacy Policy: We uphold FERPA, GDPR, and rigorous student data privacy standards.'); }} className="hover:text-white transition-colors">Privacy Policy</a>
            <span className="text-[#8E1020]">·</span>
            <a href="#terms" onClick={(e) => { e.preventDefault(); alert('Terms of Enrollment: Detailed in the annual Parent & Student Handbook.'); }} className="hover:text-white transition-colors">Terms of Enrollment</a>
            <span className="text-[#8E1020]">·</span>
            <a href="#accessibility" onClick={(e) => { e.preventDefault(); alert('Accessibility: Nova Crest is committed to WCAG 2.1 AA accessible digital experiences.'); }} className="hover:text-white transition-colors">Accessibility</a>
          </div>
        </div>

      </div>
    </footer>
  );
};
