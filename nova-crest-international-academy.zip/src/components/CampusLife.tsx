import React, { useState } from 'react';
import { ArrowRight, Trophy, Sparkles, Filter, X } from 'lucide-react';
import { CAMPUS_ACTIVITIES } from '../data/schoolData';
import { Activity } from '../types';

export const CampusLife: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [activeModalActivity, setActiveModalActivity] = useState<Activity | null>(null);

  const categories = ['All', 'Athletics', 'Performing Arts', 'Leadership', 'Visual Arts', 'Clubs', 'Community'];

  const filteredActivities = activeCategory === 'All'
    ? CAMPUS_ACTIVITIES
    : CAMPUS_ACTIVITIES.filter((a) => a.category === activeCategory);

  return (
    <section id="campus-life" className="py-20 lg:py-28 bg-[#FAF8F3] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
          <div>
            <div className="inline-flex items-center gap-2 mb-3 text-[#8E1020] text-xs uppercase tracking-[0.2em] font-semibold">
              <span className="w-6 h-[1.5px] bg-[#C7A34A]" />
              <span>Beyond The Classroom</span>
            </div>
            <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-[#242424] leading-tight">
              Experience. Explore. Belong.
            </h2>
          </div>
          <p className="mt-4 md:mt-0 text-sm sm:text-base text-[#6B6B6B] max-w-md">
            Our vibrant campus life ensures that passions outside the syllabus are nurtured with 
            equal enthusiasm, rigor, and championship coaching.
          </p>
        </div>

        {/* Filter Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8 no-scrollbar" role="tablist">
          {categories.map((cat) => (
            <button
              key={cat}
              role="tab"
              aria-selected={activeCategory === cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-4 py-2 text-xs font-semibold rounded-full transition-all whitespace-nowrap cursor-pointer ${
                activeCategory === cat
                  ? 'bg-[#8E1020] text-white shadow-sm'
                  : 'bg-white text-[#6B6B6B] hover:text-[#242424] border border-[#E8E3DA]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Activity Cards Responsive Masonry-like Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {filteredActivities.map((act) => (
            <div
              key={act.id}
              onClick={() => setActiveModalActivity(act)}
              className="relative rounded-2xl overflow-hidden h-80 sm:h-96 shadow-[0_8px_30px_rgba(36,36,36,0.08)] cursor-pointer group border border-[#E8E3DA] bg-neutral-900"
            >
              {/* Background Image */}
              <img
                src={act.image}
                alt={act.title}
                className="w-full h-full object-cover object-center group-hover:scale-108 transition-transform duration-700 ease-out"
                loading="lazy"
                referrerPolicy="no-referrer"
              />

              {/* Gradient Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/35 to-transparent group-hover:from-black/90 transition-colors duration-300" />

              {/* Top Category Badge */}
              <div className="absolute top-4 left-4">
                <span className="bg-[#650A16]/90 backdrop-blur-xs text-[#FAF8F3] text-[11px] font-semibold px-3 py-1 rounded-md border border-[#C7A34A]/40 uppercase tracking-wider">
                  {act.category}
                </span>
              </div>

              {/* Bottom Content Card */}
              <div className="absolute inset-x-0 bottom-0 p-6 flex flex-col justify-end text-white">
                <div className="flex items-center gap-1.5 text-xs text-[#E5D09A] font-semibold mb-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{act.highlight}</span>
                </div>
                
                <h3 className="font-display text-xl sm:text-2xl font-bold mb-2 group-hover:text-[#E5D09A] transition-colors leading-snug">
                  {act.title}
                </h3>

                <p className="text-xs text-white/80 line-clamp-2 mb-3 leading-relaxed">
                  {act.description}
                </p>

                <div className="inline-flex items-center gap-2 text-xs font-semibold text-white group-hover:text-[#E5D09A] transition-colors">
                  <span>Explore Activity</span>
                  <ArrowRight className="w-4 h-4 transform group-hover:translate-x-2 transition-transform duration-300" />
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Activity Detail Modal */}
      {activeModalActivity && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-white rounded-2xl max-w-xl w-full border border-[#E8E3DA] overflow-hidden shadow-2xl relative">
            <div className="relative h-56 bg-neutral-900">
              <img
                src={activeModalActivity.image}
                alt={activeModalActivity.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
              <button
                type="button"
                onClick={() => setActiveModalActivity(null)}
                className="absolute top-4 right-4 p-2 rounded-full bg-black/50 text-white hover:bg-black/80 transition-colors"
                aria-label="Close dialog"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="absolute bottom-4 left-6 right-6 text-white">
                <span className="text-xs uppercase tracking-widest text-[#E5D09A] font-semibold">
                  {activeModalActivity.category} · {activeModalActivity.highlight}
                </span>
                <h3 className="font-display text-2xl font-bold mt-1">
                  {activeModalActivity.title}
                </h3>
              </div>
            </div>

            <div className="p-6 space-y-4">
              <p className="text-sm text-[#6B6B6B] leading-relaxed">
                {activeModalActivity.description}
              </p>
              <div className="bg-[#FBF2F3] p-4 rounded-xl border border-[#8E1020]/20 text-xs text-[#242424] space-y-1">
                <div className="font-bold text-[#8E1020]">Co-Curricular Participation:</div>
                <div>All Nova Crest students participate in at least two enrichment programs each semester to foster balanced personal growth, teamwork, and creative discipline.</div>
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="button"
                  onClick={() => setActiveModalActivity(null)}
                  className="px-5 py-2 bg-[#8E1020] hover:bg-[#650A16] text-white text-xs font-semibold rounded-md transition-colors"
                >
                  Close Window
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
