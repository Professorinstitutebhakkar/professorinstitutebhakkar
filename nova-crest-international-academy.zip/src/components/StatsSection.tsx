import React, { useState, useEffect, useRef } from 'react';
import { 
  GraduationCap, 
  Users, 
  BookMarked, 
  Sparkles, 
  Target, 
  Compass 
} from 'lucide-react';

interface StatItem {
  icon: React.ElementType;
  value: number;
  suffix: string;
  label: string;
  sublabel: string;
}

const STATS: StatItem[] = [
  {
    icon: GraduationCap,
    value: 18,
    suffix: '+',
    label: 'Years of Excellence',
    sublabel: 'Chartered in 2011 with global accreditation',
  },
  {
    icon: Users,
    value: 2400,
    suffix: '+',
    label: 'Students Inspired',
    sublabel: 'Representing 42 nationalities worldwide',
  },
  {
    icon: BookMarked,
    value: 140,
    suffix: '+',
    label: 'Dedicated Educators',
    sublabel: '82% holding postgraduate master’s degrees',
  },
  {
    icon: Target,
    value: 16,
    suffix: ':1',
    label: 'Student-to-Faculty Ratio',
    sublabel: 'Guaranteed personalized mentorship',
  },
  {
    icon: Sparkles,
    value: 98,
    suffix: '%',
    label: 'University Pathway Success',
    sublabel: 'First-choice tertiary placement rate',
  },
  {
    icon: Compass,
    value: 30,
    suffix: '+',
    label: 'Clubs & Societies',
    sublabel: 'From robotics leagues to civic debate',
  },
];

export const StatsSection: React.FC = () => {
  const [hasAnimated, setHasAnimated] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);
  const [counts, setCounts] = useState<number[]>(STATS.map(() => 0));

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !hasAnimated) {
          setHasAnimated(true);

          const duration = 1800; // ms
          const startTime = performance.now();

          const animate = (currentTime: number) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            // Ease out cubic
            const easeProgress = 1 - Math.pow(1 - progress, 3);

            setCounts(
              STATS.map((stat) => Math.floor(stat.value * easeProgress))
            );

            if (progress < 1) {
              requestAnimationFrame(animate);
            } else {
              setCounts(STATS.map((stat) => stat.value));
            }
          };

          requestAnimationFrame(animate);
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, [hasAnimated]);

  return (
    <section 
      ref={sectionRef} 
      className="py-14 bg-white border-y border-[#E8E3DA] relative z-10"
      aria-label="Institutional Key Statistics"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6 lg:gap-8">
          {STATS.map((item, index) => {
            const Icon = item.icon;
            return (
              <div
                key={index}
                className="flex flex-col items-center text-center p-4 rounded-xl border border-[#FAF8F3] hover:border-[#E8E3DA] transition-all duration-300 hover:shadow-xs group"
              >
                {/* Subtle Icon Accent */}
                <div className="w-10 h-10 rounded-full bg-[#FAF8F3] border border-[#E8E3DA] group-hover:border-[#C7A34A]/40 flex items-center justify-center mb-3 transition-colors">
                  <Icon className="w-5 h-5 text-[#8E1020]" />
                </div>

                {/* Animated Stat Value */}
                <div className="font-display text-2xl sm:text-3xl lg:text-4xl font-bold text-[#8E1020] tabular-nums tracking-tight mb-1">
                  {counts[index].toLocaleString()}
                  <span>{item.suffix}</span>
                </div>

                {/* Label */}
                <div className="text-xs font-bold text-[#242424] mb-1">
                  {item.label}
                </div>

                {/* Subtext */}
                <div className="text-[11px] text-[#6B6B6B] leading-tight">
                  {item.sublabel}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
