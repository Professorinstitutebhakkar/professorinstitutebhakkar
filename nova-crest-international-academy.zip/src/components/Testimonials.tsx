import React from 'react';
import { Star, Quote } from 'lucide-react';
import { TESTIMONIALS } from '../data/schoolData';

export const Testimonials: React.FC = () => {
  return (
    <section className="py-20 lg:py-28 bg-[#FAF8F3] border-t border-[#E8E3DA] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 mb-3 text-[#8E1020] text-xs uppercase tracking-[0.2em] font-semibold">
            <span className="w-6 h-[1.5px] bg-[#C7A34A]" />
            <span>Community Voices</span>
            <span className="w-6 h-[1.5px] bg-[#C7A34A]" />
          </div>
          <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-[#242424] leading-tight mb-4">
            What Families Say
          </h2>
          <p className="text-base sm:text-lg text-[#6B6B6B]">
            Hear from our international parent body on how Nova Crest nurtures scholarly ambition, 
            resilience, and genuine happiness.
          </p>
        </div>

        {/* 3 Testimonial Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {TESTIMONIALS.map((item) => (
            <div
              key={item.id}
              className="bg-white rounded-2xl p-8 border border-[#E8E3DA] shadow-[0_4px_24px_rgba(36,36,36,0.03)] hover:shadow-[0_16px_36px_rgba(101,10,22,0.08)] hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between relative group"
            >
              {/* Subtle Quote Mark in Burgundy */}
              <div className="w-10 h-10 rounded-full bg-[#FBF2F3] text-[#8E1020] flex items-center justify-center mb-6 shrink-0">
                <Quote className="w-5 h-5 fill-current" />
              </div>

              <div>
                {/* 5 Stars Rating */}
                <div className="flex items-center gap-1 mb-4" aria-label={`${item.rating} out of 5 stars`}>
                  {[...Array(item.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-[#C7A34A] text-[#C7A34A]" />
                  ))}
                </div>

                {/* Quote Text */}
                <p className="text-sm sm:text-base text-[#242424] leading-relaxed italic mb-8 font-serif">
                  “{item.quote}”
                </p>
              </div>

              {/* Author Row */}
              <div className="flex items-center gap-3.5 pt-6 border-t border-[#FAF8F3]">
                <div className="w-11 h-11 rounded-full bg-[#650A16] text-[#FAF8F3] font-bold text-xs flex items-center justify-center border border-[#C7A34A]/40 shrink-0">
                  {item.initials}
                </div>
                <div>
                  <h3 className="text-sm font-bold text-[#242424] leading-tight">
                    {item.parentName}
                  </h3>
                  <div className="text-xs text-[#6B6B6B] mt-0.5">
                    {item.relation} · <span className="text-[#8E1020] font-medium">{item.studentGrade}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
