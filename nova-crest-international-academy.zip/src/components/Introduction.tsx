import React, { useState } from 'react';
import { ArrowRight, MapPin, CheckCircle2, BookOpen } from 'lucide-react';
import { ASSETS } from '../data/schoolData';

export const Introduction: React.FC = () => {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <section id="story" className="py-20 lg:py-28 bg-[#FAF8F3] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Left Column: Campus Architectural Photo */}
          <div className="lg:col-span-6 relative">
            <div className="relative rounded-2xl overflow-hidden border border-[#E8E3DA] shadow-[0_16px_40px_rgba(36,36,36,0.08)] bg-neutral-100 group">
              <img
                src={ASSETS.campusArchitecture}
                alt="Nova Crest International Academy contemporary architectural campus and lawns"
                className="w-full h-[400px] sm:h-[460px] lg:h-[520px] object-cover group-hover:scale-103 transition-transform duration-700 ease-out"
                loading="lazy"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent pointer-events-none" />

              {/* Established Campus Badge */}
              <div className="absolute top-6 left-6 bg-[#650A16] text-[#FAF8F3] px-4 py-2 rounded-lg text-xs font-semibold tracking-wide flex items-center gap-2 shadow-lg border border-[#C7A34A]/40">
                <MapPin className="w-3.5 h-3.5 text-[#C7A34A]" />
                <span>Est. 2011 · 24-Acre Parkland Campus</span>
              </div>

              {/* Bottom Quote Caption */}
              <div className="absolute bottom-6 left-6 right-6 text-white text-xs sm:text-sm font-serif italic drop-shadow-md">
                “Architecture crafted to invite natural light, collaborative discovery, and serene focus.”
              </div>
            </div>
          </div>

          {/* Right Column: School Story & Philosophy */}
          <div className="lg:col-span-6 flex flex-col items-start text-left">
            <div className="inline-flex items-center gap-2 mb-3 text-[#8E1020] text-xs uppercase tracking-[0.2em] font-semibold">
              <span className="w-6 h-[1.5px] bg-[#C7A34A]" />
              <span>Welcome to Nova Crest</span>
            </div>

            <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-[#242424] leading-tight mb-6">
              Where Curiosity Becomes Confidence
            </h2>

            <div className="space-y-4 text-[#6B6B6B] text-base leading-relaxed mb-8">
              <p>
                Founded on the belief that education should cultivate both intellectual brilliance 
                and generous human spirit, Nova Crest International Academy has established itself 
                as a beacon of transformative scholarship for learners from around the globe.
              </p>
              <p>
                Here, students do not simply memorize answers—they formulate rigorous questions. 
                Our inquiry-centered pedagogy unites the analytical discipline of international 
                curricula with expansive creative arts, competitive athletics, and community leadership.
              </p>
              {isExpanded && (
                <p className="text-[#242424] font-normal border-l-2 border-[#8E1020] pl-4 py-1 italic bg-[#FBF2F3]/60 rounded-r-md transition-all">
                  From our Reggio-inspired Early Years workshops to our capstone International Baccalaureate 
                  theses, our faculty mentors guide each learner toward intellectual autonomy, ethical 
                  maturity, and a lifelong devotion to purposeful service.
                </p>
              )}
            </div>

            <button
              type="button"
              onClick={() => setIsExpanded(!isExpanded)}
              className="inline-flex items-center gap-2 text-sm font-semibold text-[#8E1020] hover:text-[#650A16] transition-colors mb-10 group cursor-pointer"
            >
              <span>{isExpanded ? 'Show Less' : 'Discover Our Story'}</span>
              <ArrowRight className="w-4 h-4 text-[#C7A34A] group-hover:translate-x-1 transition-transform" />
            </button>

            {/* Our Promise Signature Card */}
            <div className="w-full bg-white p-6 rounded-xl border border-[#E8E3DA] shadow-xs relative">
              <div className="text-xs uppercase tracking-[0.16em] text-[#C7A34A] font-bold mb-1 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#8E1020]" />
                Our Institutional Promise
              </div>
              <blockquote className="font-display text-lg text-[#242424] font-semibold italic mb-3 leading-snug">
                “Every learner is known, challenged, supported, and inspired.”
              </blockquote>
              <div className="flex items-center justify-between text-xs text-[#6B6B6B] pt-3 border-t border-[#E8E3DA]">
                <div>
                  <span className="font-semibold text-[#242424]">Dr. Margaret Sterling, Ph.D.</span>
                  <span className="block text-[11px] text-[#6B6B6B]">Head of School & Chief Academic Officer</span>
                </div>
                <div className="font-serif italic text-base text-[#8E1020]">
                  Margaret Sterling
                </div>
              </div>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
