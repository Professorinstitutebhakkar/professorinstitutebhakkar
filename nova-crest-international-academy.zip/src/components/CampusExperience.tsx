import React from 'react';
import { 
  CheckCircle2, 
  ArrowRight, 
  ShieldCheck, 
  Layers, 
  Trees, 
  Sparkles,
  Compass
} from 'lucide-react';
import { ASSETS } from '../data/schoolData';

interface CampusExperienceProps {
  onExploreCampus: () => void;
}

const CAMPUS_FACILITIES = [
  {
    title: 'Smart Classrooms',
    desc: 'Ergonomic learning environments with 86" 4K interactive boards and flexible modular seating.',
  },
  {
    title: 'Advanced Science & Innovation Labs',
    desc: 'University-grade chemistry, biology, physics, and robotics maker spaces.',
  },
  {
    title: 'Performing Arts Auditorium',
    desc: '650-seat acoustically tuned concert hall, black box theater, and soundproof music suites.',
  },
  {
    title: 'Championship Athletics Arena',
    desc: 'FIFA-standard turf pitch, Olympic-length pool, 400m synthetic track, and dual sports pavilions.',
  },
  {
    title: 'Library & Discovery Center',
    desc: 'Two-story literary sanctuary housing 35,000+ volumes, digital databases, and quiet research pods.',
  },
  {
    title: 'Round-the-Clock Secure Access',
    desc: 'Gated campus perimeter, biometric access protocols, and 24/7 trained security personnel.',
  },
  {
    title: 'Student Ideation & Collaboration Hubs',
    desc: 'Dedicated open-concept lounges designed for peer study, student councils, and team projects.',
  },
  {
    title: '24-Acre Parkland & Eco Gardens',
    desc: 'Protected arboretum, solar teaching pavilion, and organic micro-farm maintained by students.',
  },
];

export const CampusExperience: React.FC<CampusExperienceProps> = ({ onExploreCampus }) => {
  return (
    <section id="experience" className="py-20 lg:py-28 bg-white border-t border-[#E8E3DA] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Left Column: Image with Subtle Gold Border Decoration */}
          <div className="lg:col-span-6 relative">
            {/* Subtle Vertical Gold Line */}
            <div className="hidden lg:block absolute -left-6 top-10 bottom-10 w-[2px] bg-gradient-to-b from-[#C7A34A] via-[#E5D09A] to-transparent" />

            <div className="relative rounded-2xl overflow-hidden border border-[#E8E3DA] shadow-[0_20px_45px_rgba(36,36,36,0.1)] group">
              <img
                src={ASSETS.library}
                alt="Nova Crest state-of-the-art campus library and discovery center"
                className="w-full h-[450px] sm:h-[520px] lg:h-[580px] object-cover object-center group-hover:scale-104 transition-transform duration-700 ease-out"
                loading="lazy"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent pointer-events-none" />

              {/* Floating Architectural Stat Box */}
              <div className="absolute bottom-6 left-6 right-6 bg-white/95 backdrop-blur-md p-5 rounded-xl border border-[#E8E3DA] shadow-lg flex items-center justify-between">
                <div>
                  <div className="text-xs uppercase tracking-wider text-[#8E1020] font-bold">
                    Campus Infrastructure
                  </div>
                  <div className="font-display text-lg font-bold text-[#242424]">
                    24 Parkland Acres · 12 Purpose Studios
                  </div>
                </div>
                <div className="w-10 h-10 rounded-full bg-[#FBF2F3] border border-[#8E1020]/20 flex items-center justify-center shrink-0">
                  <Compass className="w-5 h-5 text-[#8E1020]" />
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Campus Description & Facility Checklist */}
          <div className="lg:col-span-6 flex flex-col items-start text-left">
            <div className="inline-flex items-center gap-2 mb-3 text-[#8E1020] text-xs uppercase tracking-[0.2em] font-semibold">
              <span className="w-6 h-[1.5px] bg-[#C7A34A]" />
              <span>Campus Experience</span>
            </div>

            <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-[#242424] leading-tight mb-4">
              A Campus Designed Around the Learner
            </h2>

            <p className="text-base text-[#6B6B6B] leading-relaxed mb-8">
              Every square meter of Nova Crest is intentionally conceived to elevate curiosity, 
              encourage natural collaboration, and maintain an environment of safety and serenity.
            </p>

            {/* 8 Feature List Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-4 w-full mb-10">
              {CAMPUS_FACILITIES.map((facility, index) => (
                <div key={index} className="flex items-start gap-3">
                  <CheckCircle2 className="w-4 h-4 text-[#8E1020] shrink-0 mt-0.5" />
                  <div>
                    <h3 className="text-xs font-bold text-[#242424] leading-snug">
                      {facility.title}
                    </h3>
                    <p className="text-[11px] text-[#6B6B6B] leading-normal mt-0.5">
                      {facility.desc}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* CTA Button */}
            <button
              type="button"
              onClick={onExploreCampus}
              className="inline-flex items-center gap-3 px-7 py-3.5 bg-[#8E1020] hover:bg-[#650A16] text-white text-sm font-semibold rounded-md shadow-[0_4px_16px_rgba(142,16,32,0.2)] hover:shadow-[0_8px_24px_rgba(142,16,32,0.3)] transition-all cursor-pointer group"
            >
              <span>Explore Our Campus Facilities</span>
              <ArrowRight className="w-4 h-4 text-[#E5D09A] group-hover:translate-x-1 transition-transform" />
            </button>

          </div>

        </div>
      </div>
    </section>
  );
};
