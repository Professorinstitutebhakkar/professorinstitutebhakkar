import React from 'react';

interface CrestLogoProps {
  variant?: 'light' | 'dark';
  className?: string;
  showTagline?: boolean;
}

export const CrestLogo: React.FC<CrestLogoProps> = ({
  variant = 'dark',
  className = '',
  showTagline = true,
}) => {
  const isLight = variant === 'light';
  const textColor = isLight ? 'text-white' : 'text-[#242424]';
  const subtextColor = isLight ? 'text-[#E5D09A]' : 'text-[#6B6B6B]';
  const crestFill = isLight ? '#FAF8F3' : '#8E1020';
  const goldAccent = '#C7A34A';

  return (
    <div className={`flex items-center gap-3.5 ${className}`}>
      {/* SVG Original Crest Emblem */}
      <svg
        width="44"
        height="48"
        viewBox="0 0 44 48"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="shrink-0"
        aria-hidden="true"
      >
        {/* Shield Outer Outline */}
        <path
          d="M22 2L41 7.8V23.6C41 35.8 32.8 44.2 22 47C11.2 44.2 3 35.8 3 23.6V7.8L22 2Z"
          fill={crestFill}
          stroke={goldAccent}
          strokeWidth="1.75"
        />
        {/* Inner Decorative Shield Boundary */}
        <path
          d="M22 5.5L37.5 10.2V23C37.5 32.8 30.8 39.8 22 42.2C13.2 39.8 6.5 32.8 6.5 23V10.2L22 5.5Z"
          stroke={isLight ? '#650A16' : '#FAF8F3'}
          strokeWidth="0.8"
          strokeOpacity="0.4"
        />
        {/* Guiding North Star */}
        <path
          d="M22 10.5L23.4 15.2L28 16.5L23.4 17.8L22 22.5L20.6 17.8L16 16.5L20.6 15.2L22 10.5Z"
          fill={goldAccent}
        />
        {/* Open Book of Knowledge */}
        <path
          d="M14 26C16.8 24.8 20 25.4 22 26.6C24 25.4 27.2 24.8 30 26V33C27.2 31.8 24 32.4 22 33.6C20 32.4 16.8 31.8 14 33V26Z"
          fill={isLight ? '#650A16' : '#FAF8F3'}
        />
        <path
          d="M22 26.6V33.6"
          stroke={goldAccent}
          strokeWidth="1.2"
        />
        {/* Ascending Sun Rays */}
        <path
          d="M17 21L15 19.5M27 21L29 19.5M22 18.5V20.5"
          stroke={goldAccent}
          strokeWidth="1.2"
          strokeLinecap="round"
        />
      </svg>

      {/* Brand Typography */}
      <div className="flex flex-col text-left">
        <span
          className={`font-serif tracking-tight text-lg sm:text-xl font-bold leading-tight ${textColor}`}
          style={{ letterSpacing: '0.02em' }}
        >
          NOVA CREST
        </span>
        <span
          className={`text-[10px] sm:text-[11px] font-medium tracking-[0.18em] uppercase ${subtextColor}`}
        >
          International Academy
        </span>
        {showTagline && (
          <span className="hidden lg:block text-[9px] tracking-wider text-[#8E1020]/70 dark:text-neutral-400 font-sans mt-0.5">
            Inspiring Minds · Building Futures
          </span>
        )}
      </div>
    </div>
  );
};
