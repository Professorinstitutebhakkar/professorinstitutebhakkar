import React, { useState } from 'react';
import { ArrowRight, BookOpen, Sparkles, Check, X, GraduationCap } from 'lucide-react';
import { ACADEMIC_PROGRAMS } from '../data/schoolData';
import { Program } from '../types';

export const AcademicPrograms: React.FC = () => {
  const [selectedProgram, setSelectedProgram] = useState<Program | null>(null);

  return (
    <section id="academics" className="py-20 lg:py-28 bg-[#FAF8F3] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 mb-3 text-[#8E1020] text-xs uppercase tracking-[0.2em] font-semibold">
            <span className="w-6 h-[1.5px] bg-[#C7A34A]" />
            <span>Academic Pathways</span>
            <span className="w-6 h-[1.5px] bg-[#C7A34A]" />
          </div>
          <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-[#242424] leading-tight mb-4">
            A Learning Journey Designed for Every Stage
          </h2>
          <p className="text-base sm:text-lg text-[#6B6B6B]">
            From early sensory discovery to rigorous pre-university scholarly research, 
            our continuum of education is tailored to ignite potential at each developmental milestone.
          </p>
        </div>

        {/* 5 Responsive Program Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
          {ACADEMIC_PROGRAMS.map((prog, index) => (
            <div
              key={prog.id}
              className="bg-white rounded-2xl border border-[#E8E3DA] overflow-hidden shadow-[0_4px_20px_rgba(36,36,36,0.04)] hover:shadow-[0_16px_36px_rgba(101,10,22,0.1)] hover:-translate-y-1.5 transition-all duration-300 flex flex-col group"
            >
              {/* Image Container with Zoom */}
              <div className="relative h-48 overflow-hidden bg-neutral-100">
                <img
                  src={prog.image}
                  alt={prog.title}
                  className="w-full h-full object-cover object-center group-hover:scale-106 transition-transform duration-500 ease-out"
                  loading="lazy"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent pointer-events-none" />

                {/* Grade / Stage Pill */}
                <div className="absolute top-3 left-3 bg-[#650A16]/90 backdrop-blur-xs text-[#FAF8F3] px-2.5 py-1 rounded-md text-[11px] font-semibold tracking-wide border border-[#C7A34A]/30">
                  {prog.ageRange}
                </div>
              </div>

              {/* Card Body */}
              <div className="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <div className="text-[11px] uppercase tracking-wider font-semibold text-[#C7A34A] mb-1">
                    {prog.subtitle}
                  </div>
                  <h3 className="font-display text-lg font-bold text-[#242424] mb-2 group-hover:text-[#8E1020] transition-colors leading-snug">
                    {prog.title}
                  </h3>
                  <p className="text-xs text-[#6B6B6B] leading-relaxed mb-4 line-clamp-3">
                    {prog.description}
                  </p>
                </div>

                <div className="pt-3 border-t border-[#FAF8F3]">
                  <button
                    type="button"
                    onClick={() => setSelectedProgram(prog)}
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-[#8E1020] hover:text-[#650A16] group-hover:underline cursor-pointer"
                  >
                    <span>Explore Program</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Program Detail Inspection Modal */}
      {selectedProgram && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto border border-[#E8E3DA] shadow-2xl relative">
            {/* Modal Header Image */}
            <div className="relative h-60 w-full overflow-hidden bg-neutral-900">
              <img
                src={selectedProgram.image}
                alt={selectedProgram.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
              
              <button
                type="button"
                onClick={() => setSelectedProgram(null)}
                className="absolute top-4 right-4 p-2 rounded-full bg-black/50 text-white hover:bg-black/80 transition-colors cursor-pointer"
                aria-label="Close dialog"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="absolute bottom-4 left-6 right-6 text-white">
                <span className="text-xs uppercase tracking-widest text-[#E5D09A] font-semibold">
                  {selectedProgram.subtitle} · {selectedProgram.ageRange}
                </span>
                <h3 className="font-display text-2xl sm:text-3xl font-bold mt-1">
                  {selectedProgram.title}
                </h3>
              </div>
            </div>

            {/* Modal Content */}
            <div className="p-6 sm:p-8 space-y-6">
              <div>
                <h4 className="text-xs uppercase tracking-wider font-bold text-[#8E1020] mb-1">
                  Curriculum Framework
                </h4>
                <p className="text-base font-semibold text-[#242424]">
                  {selectedProgram.curriculum}
                </p>
              </div>

              <div>
                <h4 className="text-xs uppercase tracking-wider font-bold text-[#8E1020] mb-2">
                  Pedagogical Focus & Philosophy
                </h4>
                <p className="text-sm text-[#6B6B6B] leading-relaxed">
                  {selectedProgram.description} Our educators prioritize student agency, inquiry projects, and personalized learning plans that ensure no student is left behind while advanced scholars are continually stretched.
                </p>
              </div>

              <div>
                <h4 className="text-xs uppercase tracking-wider font-bold text-[#8E1020] mb-3">
                  Signature Program Highlights
                </h4>
                <ul className="space-y-2">
                  {selectedProgram.keyHighlights.map((highlight, idx) => (
                    <li key={idx} className="flex items-center gap-3 text-sm text-[#242424]">
                      <div className="w-5 h-5 rounded-full bg-[#FBF2F3] text-[#8E1020] flex items-center justify-center shrink-0">
                        <Check className="w-3.5 h-3.5" />
                      </div>
                      <span>{highlight}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="pt-4 border-t border-[#E8E3DA] flex items-center justify-between">
                <a
                  href="#admissions"
                  onClick={() => setSelectedProgram(null)}
                  className="px-6 py-2.5 bg-[#8E1020] hover:bg-[#650A16] text-white text-xs sm:text-sm font-semibold rounded-md shadow-sm transition-colors"
                >
                  Apply for this Pathway
                </a>
                <button
                  type="button"
                  onClick={() => setSelectedProgram(null)}
                  className="text-xs font-semibold text-[#6B6B6B] hover:text-[#242424]"
                >
                  Close Preview
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
