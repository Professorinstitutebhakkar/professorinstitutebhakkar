import React from 'react';
import { 
  Cpu, 
  UserCheck, 
  Globe2, 
  ShieldCheck, 
  Palette, 
  HeartHandshake 
} from 'lucide-react';
import { WHY_NOVA_CREST } from '../data/schoolData';

const ICONS = [Cpu, UserCheck, Globe2, ShieldCheck, Palette, HeartHandshake];

export const WhyNovaCrest: React.FC = () => {
  return (
    <section id="why-us" className="py-20 lg:py-28 bg-[#FAF8F3] border-t border-[#E8E3DA] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-16 text-left">
          <div className="inline-flex items-center gap-2 mb-3 text-[#8E1020] text-xs uppercase tracking-[0.2em] font-semibold">
            <span className="w-6 h-[1.5px] bg-[#C7A34A]" />
            <span>The Nova Crest Distinction</span>
          </div>
          <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-[#242424] leading-tight mb-4">
            What Makes Nova Crest Different
          </h2>
          <p className="text-base sm:text-lg text-[#6B6B6B]">
            We reject one-size-fits-all education. Our institution is engineered around individual 
            potential, intellectual daring, and the timeless virtues of ethical leadership.
          </p>
        </div>

        {/* Asymmetric 6 Feature Blocks */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {WHY_NOVA_CREST.map((item, index) => {
            const IconComponent = ICONS[index % ICONS.length];
            return (
              <div
                key={item.number}
                className="bg-white rounded-2xl p-8 border border-[#E8E3DA] hover:border-[#C7A34A]/50 shadow-[0_4px_24px_rgba(36,36,36,0.03)] hover:shadow-[0_16px_36px_rgba(101,10,22,0.08)] hover:-translate-y-1 transition-all duration-300 relative overflow-hidden group flex flex-col justify-between"
              >
                {/* Subtle Decorative Gold Accent Line */}
                <div className="w-10 h-[2px] bg-[#C7A34A] mb-6 group-hover:w-16 transition-all duration-300" />

                <div>
                  {/* Top Row: Icon + Number */}
                  <div className="flex items-center justify-between mb-5">
                    <div className="w-12 h-12 rounded-xl bg-[#FAF8F3] border border-[#E8E3DA] group-hover:bg-[#FBF2F3] group-hover:border-[#8E1020]/30 flex items-center justify-center transition-colors">
                      <IconComponent className="w-6 h-6 text-[#8E1020]" />
                    </div>
                    <span className="font-display text-2xl font-bold text-[#E8E3DA] group-hover:text-[#C7A34A] transition-colors tabular-nums">
                      {item.number}
                    </span>
                  </div>

                  {/* Heading */}
                  <h3 className="font-display text-xl font-bold text-[#242424] mb-3 group-hover:text-[#8E1020] transition-colors leading-snug">
                    {item.title}
                  </h3>

                  {/* Description */}
                  <p className="text-sm text-[#6B6B6B] leading-relaxed">
                    {item.description}
                  </p>
                </div>

                <div className="pt-6 mt-6 border-t border-[#FAF8F3] flex items-center justify-between text-xs text-[#8E1020] font-semibold opacity-0 group-hover:opacity-100 transition-opacity">
                  <span>Explore Standard</span>
                  <span>→</span>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
