import React from 'react';
import { 
  ArrowRight, 
  Play, 
  Globe2, 
  Compass, 
  ShieldCheck, 
  Award,
  Sparkles
} from 'lucide-react';
import { ASSETS } from '../data/schoolData';

interface HeroProps {
  onExploreAdmissions: () => void;
  onOpenVirtualTour: () => void;
}

export const Hero: React.FC<HeroProps> = ({ 
  onExploreAdmissions, 
  onOpenVirtualTour 
}) => {
  return (
    <section 
      id="home" 
      className="relative overflow-hidden bg-gradient-to-b from-[#FAF8F3] via-[#FAF8F3] to-[#FBF2F3]/40 pt-10 pb-16 lg:pt-16 lg:pb-24 border-b border-[#E8E3DA]"
    >
      {/* Subtle architectural background geometry */}
      <div className="absolute inset-0 pointer-events-none opacity-[0.03] bg-[radial-gradient(#8E1020_1px,transparent_1px)] [background-size:24px_24px]" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Editorial Content (7 columns on desktop) */}
          <div className="lg:col-span-7 flex flex-col items-start text-left z-10">
            {/* Eyebrow Label */}
            <div className="inline-flex items-center gap-2 mb-4 text-[#8E1020] text-xs uppercase tracking-[0.2em] font-semibold">
              <span className="w-6 h-[1.5px] bg-[#C7A34A]" />
              <span>A Place to Discover Your Potential</span>
            </div>

            {/* Main Headline */}
            <h1 className="font-display text-4xl sm:text-5xl md:text-6xl lg:text-[68px] font-bold text-[#242424] leading-[1.08] tracking-tight mb-6">
              Learn Boldly.<br />
              <span className="text-[#8E1020]">Live Purposefully.</span><br />
              Lead Tomorrow.
            </h1>

            {/* Supporting Copy */}
            <p className="text-base sm:text-lg text-[#6B6B6B] leading-relaxed max-w-2xl mb-8 font-normal">
              At Nova Crest International Academy, we unite academic rigor with character education, 
              innovative inquiry, and global perspective. Within a safe, inspiring 24-acre parkland campus, 
              every learner is challenged to think critically, create fearlessly, and lead with empathy.
            </p>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 w-full sm:w-auto mb-10">
              <button
                type="button"
                onClick={onExploreAdmissions}
                className="inline-flex items-center justify-center gap-3 px-7 py-3.5 bg-[#8E1020] hover:bg-[#650A16] text-white text-sm sm:text-base font-semibold rounded-md shadow-[0_8px_20px_rgba(142,16,32,0.18)] hover:shadow-[0_12px_24px_rgba(142,16,32,0.28)] transform hover:-translate-y-0.5 transition-all cursor-pointer group"
              >
                <span>Explore Admissions</span>
                <ArrowRight className="w-4 h-4 text-[#E5D09A] group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                type="button"
                onClick={onOpenVirtualTour}
                className="inline-flex items-center justify-center gap-2.5 px-6 py-3.5 border border-[#8E1020] text-[#8E1020] hover:bg-[#8E1020] hover:text-white text-sm sm:text-base font-semibold rounded-md transition-all cursor-pointer group"
              >
                <div className="w-6 h-6 rounded-full bg-[#8E1020]/10 group-hover:bg-white/20 flex items-center justify-center transition-colors">
                  <Play className="w-3 h-3 text-[#8E1020] group-hover:text-white fill-current ml-0.5" />
                </div>
                <span>Take a Virtual Tour</span>
              </button>
            </div>

            {/* Trust Markers Bar */}
            <div className="pt-6 border-t border-[#E8E3DA] w-full grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-[#FAF8F3] border border-[#C7A34A]/30 flex items-center justify-center shrink-0">
                  <Globe2 className="w-4 h-4 text-[#8E1020]" />
                </div>
                <div>
                  <div className="text-xs font-bold text-[#242424]">Globally Inspired</div>
                  <div className="text-[11px] text-[#6B6B6B]">IB & AP Curricula</div>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-[#FAF8F3] border border-[#C7A34A]/30 flex items-center justify-center shrink-0">
                  <Compass className="w-4 h-4 text-[#8E1020]" />
                </div>
                <div>
                  <div className="text-xs font-bold text-[#242424]">Student-Centered</div>
                  <div className="text-[11px] text-[#6B6B6B]">16:1 Advisory Ratio</div>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-[#FAF8F3] border border-[#C7A34A]/30 flex items-center justify-center shrink-0">
                  <ShieldCheck className="w-4 h-4 text-[#8E1020]" />
                </div>
                <div>
                  <div className="text-xs font-bold text-[#242424]">Safe & Nurturing</div>
                  <div className="text-[11px] text-[#6B6B6B]">24-Acre Parkland</div>
                </div>
              </div>
            </div>

          </div>

          {/* Right Image Composition (5 columns on desktop) */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-lg lg:max-w-none">
              
              {/* Subtle Gold Accent Frame behind image */}
              <div className="absolute -top-3 -right-3 w-full h-full rounded-2xl border-2 border-[#C7A34A]/40 pointer-events-none hidden sm:block" />

              {/* Main Image Container */}
              <div className="relative rounded-2xl overflow-hidden shadow-[0_20px_50px_rgba(36,36,36,0.14)] bg-neutral-100 border border-[#E8E3DA]">
                <img
                  src={ASSETS.heroStudents}
                  alt="Nova Crest International Academy scholars in formal blazers on school grounds"
                  className="w-full h-[400px] sm:h-[480px] lg:h-[540px] object-cover object-center transform hover:scale-102 transition-transform duration-700 ease-out"
                  loading="eager"
                  referrerPolicy="no-referrer"
                />

                {/* Soft gradient wash at bottom */}
                <div className="absolute inset-x-0 bottom-0 h-28 bg-gradient-to-t from-black/50 via-black/10 to-transparent pointer-events-none" />
                
                {/* Image caption credit */}
                <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-white/90 text-xs font-medium">
                  <span className="flex items-center gap-1.5 drop-shadow-sm">
                    <Sparkles className="w-3.5 h-3.5 text-[#E5D09A]" />
                    Main Atrium · Upper School Cohort
                  </span>
                  <span className="text-[11px] text-white/70">Academic Year 2026</span>
                </div>
              </div>

              {/* Floating Information Badge */}
              <div className="absolute -bottom-6 -left-4 sm:bottom-6 sm:-left-6 bg-white p-4 sm:p-5 rounded-xl border border-[#E8E3DA] shadow-[0_12px_30px_rgba(101,10,22,0.12)] max-w-[240px] sm:max-w-[270px]">
                <div className="flex items-start gap-3.5">
                  <div className="w-10 h-10 rounded-lg bg-[#FBF2F3] border border-[#8E1020]/20 flex items-center justify-center shrink-0">
                    <Award className="w-5 h-5 text-[#8E1020]" />
                  </div>
                  <div>
                    <div className="font-display text-2xl font-bold text-[#8E1020] leading-none mb-1">
                      15+ Years
                    </div>
                    <div className="text-xs font-semibold text-[#242424] leading-snug">
                      Growing curious minds with purpose & vision
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
