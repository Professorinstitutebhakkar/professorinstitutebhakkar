import React, { useState } from 'react';
import { ArrowRight, Calendar, Clock, X, BookOpen } from 'lucide-react';
import { NEWS_ARTICLES } from '../data/schoolData';
import { NewsArticle } from '../types';

export const NewsSection: React.FC = () => {
  const [activeArticle, setActiveArticle] = useState<NewsArticle | null>(null);

  return (
    <section id="news" className="py-20 lg:py-28 bg-white border-t border-[#E8E3DA] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16">
          <div>
            <div className="inline-flex items-center gap-2 mb-3 text-[#8E1020] text-xs uppercase tracking-[0.2em] font-semibold">
              <span className="w-6 h-[1.5px] bg-[#C7A34A]" />
              <span>Campus Journal</span>
            </div>
            <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-[#242424] leading-tight">
              What's Happening at Nova Crest
            </h2>
          </div>
          <p className="mt-4 md:mt-0 text-sm sm:text-base text-[#6B6B6B] max-w-md">
            Stories of scholarly triumphs, campus community initiatives, and visionary projects 
            from our faculty and student leaders.
          </p>
        </div>

        {/* Article Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {NEWS_ARTICLES.map((article) => (
            <article
              key={article.id}
              onClick={() => setActiveArticle(article)}
              className="bg-white rounded-2xl border border-[#E8E3DA] overflow-hidden shadow-[0_4px_20px_rgba(36,36,36,0.04)] hover:shadow-[0_16px_36px_rgba(101,10,22,0.09)] hover:-translate-y-1.5 transition-all duration-300 flex flex-col cursor-pointer group"
            >
              {/* Image Container */}
              <div className="relative h-56 overflow-hidden bg-neutral-100">
                <img
                  src={article.image}
                  alt={article.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out"
                  loading="lazy"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-4 left-4 bg-white/95 backdrop-blur-xs text-[#8E1020] px-3 py-1 rounded-md text-[11px] font-bold uppercase tracking-wider border border-[#E8E3DA]">
                  {article.category}
                </div>
              </div>

              {/* Body Content */}
              <div className="p-6 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-4 text-xs text-[#6B6B6B] mb-3">
                    <span className="flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-[#C7A34A]" />
                      <span>{article.date}</span>
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-[#C7A34A]" />
                      <span>{article.readTime}</span>
                    </span>
                  </div>

                  <h3 className="font-display text-lg sm:text-xl font-bold text-[#242424] mb-3 group-hover:text-[#8E1020] transition-colors leading-snug line-clamp-2">
                    {article.title}
                  </h3>

                  <p className="text-xs sm:text-sm text-[#6B6B6B] leading-relaxed line-clamp-3 mb-6">
                    {article.excerpt}
                  </p>
                </div>

                <div className="pt-4 border-t border-[#FAF8F3]">
                  <span className="inline-flex items-center gap-1.5 text-xs font-bold text-[#8E1020] group-hover:underline">
                    <span>Read Article</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                  </span>
                </div>
              </div>
            </article>
          ))}
        </div>

      </div>

      {/* Article Detail Modal */}
      {activeArticle && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto border border-[#E8E3DA] shadow-2xl relative">
            <div className="relative h-64 bg-neutral-900">
              <img
                src={activeArticle.image}
                alt={activeArticle.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
              <button
                type="button"
                onClick={() => setActiveArticle(null)}
                className="absolute top-4 right-4 p-2 rounded-full bg-black/50 text-white hover:bg-black/80 transition-colors"
                aria-label="Close article"
              >
                <X className="w-5 h-5" />
              </button>
              <div className="absolute bottom-4 left-6 right-6 text-white">
                <span className="text-xs uppercase tracking-widest text-[#E5D09A] font-semibold">
                  {activeArticle.category} · {activeArticle.date}
                </span>
                <h3 className="font-display text-2xl font-bold mt-1">
                  {activeArticle.title}
                </h3>
              </div>
            </div>

            <div className="p-6 sm:p-8 space-y-4">
              <p className="text-sm sm:text-base text-[#242424] leading-relaxed font-serif">
                {activeArticle.content}
              </p>
              <p className="text-sm text-[#6B6B6B] leading-relaxed">
                For further inquiries or press communications regarding this initiative, please contact the Nova Crest Office of Communications & External Affairs at communications@novacrest.edu.
              </p>

              <div className="pt-4 border-t border-[#E8E3DA] flex justify-end">
                <button
                  type="button"
                  onClick={() => setActiveArticle(null)}
                  className="px-6 py-2.5 bg-[#8E1020] hover:bg-[#650A16] text-white text-xs sm:text-sm font-semibold rounded-md transition-colors"
                >
                  Close Article
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
