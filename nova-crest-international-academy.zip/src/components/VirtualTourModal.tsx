import React, { useState } from 'react';
import { X, MapPin, Eye, Compass, ArrowRight, CheckCircle2 } from 'lucide-react';
import { ASSETS } from '../data/schoolData';

interface VirtualTourModalProps {
  isOpen: boolean;
  onClose: () => void;
  onBookLiveTour: () => void;
}

interface TourHotspot {
  id: string;
  name: string;
  category: string;
  image: string;
  description: string;
  capacity: string;
  keyFeature: string;
}

export const VirtualTourModal: React.FC<VirtualTourModalProps> = ({
  isOpen,
  onClose,
  onBookLiveTour,
}) => {
  if (!isOpen) return null;

  const hotspots: TourHotspot[] = [
    {
      id: 'atrium',
      name: 'Main Architectural Atrium & Quadrangle',
      category: 'Campus Heart',
      image: ASSETS.campusArchitecture,
      description: 'The luminous glass-fronted entrance pavilion and central quadrangle linking primary, middle, and senior academic wings.',
      capacity: 'Accommodates 1,200 attendees for assemblies',
      keyFeature: 'Biophilic natural daylight architecture with geo-thermal climate regulation',
    },
    {
      id: 'science-lab',
      name: 'Advanced Science & Robotics Ateliers',
      category: 'STEM Innovation',
      image: ASSETS.scienceLab,
      description: 'University-specification chemistry, biology, physics, and autonomous robotics laboratories with individual research workbenches.',
      capacity: '8 specialized research studios',
      keyFeature: 'Full digital data acquisition sensors, electron microscopes, and 3D prototyping print stations',
    },
    {
      id: 'library',
      name: 'Two-Story Library & Media Discovery Pods',
      category: 'Scholarly Inquiry',
      image: ASSETS.library,
      description: 'An expansive modern learning repository with 35,000+ volumes, JSTOR scholarly database access, and quiet glass-enclosed study suites.',
      capacity: '250 simultaneous researchers',
      keyFeature: 'Natural oak reading carrels with private power hubs and dedicated research librarians',
    },
    {
      id: 'performing-arts',
      name: 'Veritas Performing Arts Auditorium',
      category: 'Creative Arts',
      image: ASSETS.performingArts,
      description: 'A professional acoustic concert hall engineered for orchestral performances, dramatic theatre, choral recitals, and visiting lectures.',
      capacity: '650 acoustic theater seats',
      keyFeature: 'Steinway grand piano, motorized stage rigging, and computerized LED performance grid',
    },
    {
      id: 'athletics',
      name: 'Championship Sports Arena & Complex',
      category: 'Varsity Athletics',
      image: ASSETS.athletics,
      description: 'Multi-sport indoor sports arena, Olympic competition swimming pool, 400m synthetic running track, and FIFA-grade turf pitch.',
      capacity: 'Full varsity athletic training suites',
      keyFeature: 'Biomechanics video capture room and on-site certified athletic trainers',
    },
  ];

  const [activeSpot, setActiveSpot] = useState<TourHotspot>(hotspots[0]);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs animate-fadeIn"
      role="dialog"
      aria-modal="true"
    >
      <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[92vh] overflow-hidden border border-[#E8E3DA] shadow-2xl flex flex-col">
        {/* Header Bar */}
        <div className="p-4 sm:p-5 border-b border-[#E8E3DA] flex items-center justify-between bg-[#FAF8F3]">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-[#8E1020] text-[#FAF8F3] flex items-center justify-center">
              <Compass className="w-4 h-4 text-[#E5D09A]" />
            </div>
            <div>
              <h3 className="font-display text-lg font-bold text-[#242424]">
                Nova Crest 360° Virtual Campus Preview
              </h3>
              <p className="text-xs text-[#6B6B6B]">
                Interactive walkthrough of our 24-acre parkland facilities
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-neutral-200 text-[#6B6B6B] hover:text-[#242424] transition-colors"
            aria-label="Close virtual tour"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body: Split View */}
        <div className="grid grid-cols-1 lg:grid-cols-12 flex-1 overflow-y-auto">
          {/* Main Hotspot Preview (7 cols) */}
          <div className="lg:col-span-8 p-6 flex flex-col justify-between bg-neutral-900 text-white relative">
            <div className="relative h-64 sm:h-80 rounded-xl overflow-hidden mb-4 border border-white/10">
              <img
                src={activeSpot.image}
                alt={activeSpot.name}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
              
              <div className="absolute top-4 left-4 bg-[#650A16]/90 text-white text-xs px-3 py-1 rounded-md border border-[#C7A34A]/40 font-semibold uppercase tracking-wider">
                {activeSpot.category}
              </div>

              <div className="absolute bottom-4 left-4 right-4">
                <h4 className="font-display text-xl sm:text-2xl font-bold text-white mb-1">
                  {activeSpot.name}
                </h4>
                <div className="text-xs text-[#E5D09A] font-medium flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5" />
                  <span>Main Campus · West Quadrangle</span>
                </div>
              </div>
            </div>

            <div className="space-y-3 text-xs sm:text-sm text-neutral-300">
              <p>{activeSpot.description}</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-xs">
                <div className="bg-white/10 p-3 rounded-lg border border-white/10">
                  <span className="text-[#E5D09A] font-bold block mb-0.5">Capacity & Scale:</span>
                  <span className="text-white">{activeSpot.capacity}</span>
                </div>
                <div className="bg-white/10 p-3 rounded-lg border border-white/10">
                  <span className="text-[#E5D09A] font-bold block mb-0.5">Key Distinction:</span>
                  <span className="text-white">{activeSpot.keyFeature}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Location Selector (4 cols) */}
          <div className="lg:col-span-4 p-5 bg-[#FAF8F3] border-t lg:border-t-0 lg:border-l border-[#E8E3DA] flex flex-col justify-between">
            <div>
              <div className="text-xs font-bold uppercase tracking-wider text-[#8E1020] mb-3">
                Select Campus Zone
              </div>
              <div className="space-y-2">
                {hotspots.map((spot) => (
                  <button
                    key={spot.id}
                    onClick={() => setActiveSpot(spot)}
                    className={`w-full text-left p-3 rounded-xl border text-xs transition-all flex items-start gap-3 cursor-pointer ${
                      activeSpot.id === spot.id
                        ? 'bg-white border-[#8E1020] shadow-sm text-[#242424] font-semibold'
                        : 'bg-transparent border-[#E8E3DA] text-[#6B6B6B] hover:bg-white hover:text-[#242424]'
                    }`}
                  >
                    <div className="w-12 h-12 rounded-lg overflow-hidden shrink-0 bg-neutral-200">
                      <img src={spot.image} alt={spot.name} className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-1">
                      <div className="text-[10px] uppercase font-bold text-[#8E1020]">{spot.category}</div>
                      <div className="line-clamp-1 font-bold text-xs">{spot.name}</div>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <div className="pt-6 border-t border-[#E8E3DA] mt-6">
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onBookLiveTour();
                }}
                className="w-full py-3 px-4 bg-[#8E1020] hover:bg-[#650A16] text-white font-semibold text-xs rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-sm"
              >
                <span>Book an In-Person Tour</span>
                <ArrowRight className="w-3.5 h-3.5 text-[#E5D09A]" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
