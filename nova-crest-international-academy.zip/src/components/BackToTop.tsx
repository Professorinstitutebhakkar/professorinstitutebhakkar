import React, { useState, useEffect } from 'react';
import { ArrowUp } from 'lucide-react';

export const BackToTop: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const toggleVisibility = () => {
      setIsVisible(window.scrollY > 400);
    };

    window.addEventListener('scroll', toggleVisibility, { passive: true });
    return () => window.removeEventListener('scroll', toggleVisibility);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
  };

  if (!isVisible) return null;

  return (
    <button
      type="button"
      onClick={scrollToTop}
      className="fixed bottom-6 right-6 z-40 p-3 rounded-full bg-[#8E1020] hover:bg-[#650A16] text-[#FAF8F3] shadow-[0_4px_16px_rgba(101,10,22,0.3)] hover:shadow-[0_8px_24px_rgba(101,10,22,0.4)] transition-all duration-300 transform hover:-translate-y-1 focus:outline-none focus:ring-2 focus:ring-[#C7A34A] cursor-pointer"
      aria-label="Back to top of page"
      title="Back to top"
    >
      <ArrowUp className="w-5 h-5 text-[#E5D09A]" />
    </button>
  );
};
