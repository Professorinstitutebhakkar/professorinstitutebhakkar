import heroStudentsImg from '../assets/images/hero_students_1791362792755.jpg';
import campusArchImg from '../assets/images/campus_architecture_1791362804953.jpg';
import scienceLabImg from '../assets/images/academic_science_stem_1791362816834.jpg';
import performingArtsImg from '../assets/images/campus_performing_arts_1791362826767.jpg';
import athleticsImg from '../assets/images/campus_athletics_sports_1791362836656.jpg';
import earlyYearsImg from '../assets/images/academic_early_years_1791362885241.jpg';
import libraryImg from '../assets/images/campus_library_1791362899084.jpg';
import leadershipImg from '../assets/images/student_leadership_1791362909550.jpg';
import visualArtsImg from '../assets/images/visual_arts_studio_1791362920007.jpg';

import { Program, Activity, Testimonial, NewsArticle } from '../types';

export const ASSETS = {
  heroStudents: heroStudentsImg,
  campusArchitecture: campusArchImg,
  scienceLab: scienceLabImg,
  performingArts: performingArtsImg,
  athletics: athleticsImg,
  earlyYears: earlyYearsImg,
  library: libraryImg,
  leadership: leadershipImg,
  visualArts: visualArtsImg,
};

export const ACADEMIC_PROGRAMS: Program[] = [
  {
    id: 'early-years',
    title: 'Early Years Foundation',
    subtitle: 'Nursery to Kindergarten',
    ageRange: 'Ages 3 – 5',
    curriculum: 'Reggio-Emilia & Inquiry-Led Exploration',
    description: 'Nurturing curiosity, sensory discovery, and emotional resilience through intentional play-based learning spaces and individualized care.',
    keyHighlights: ['Bilingual language immersion', 'Sensory discovery atelier', '1:6 educator guidance'],
    image: earlyYearsImg,
  },
  {
    id: 'primary-school',
    title: 'Primary School',
    subtitle: 'Grades 1 through 5',
    ageRange: 'Ages 6 – 10',
    curriculum: 'International Primary Curriculum (IPC)',
    description: 'Building foundational mastery in literacy, conceptual mathematics, scientific inquiry, and global cultural perspectives in dynamic collaborative classrooms.',
    keyHighlights: ['Foundational STEM inquiry', 'Creative arts & vocal music', 'Daily physical literacy'],
    image: heroStudentsImg,
  },
  {
    id: 'middle-school',
    title: 'Middle School',
    subtitle: 'Grades 6 through 8',
    ageRange: 'Ages 11 – 13',
    curriculum: 'Middle Years Academic Framework',
    description: 'Empowering young adolescents with analytical thinking, self-advocacy, multidisciplinary projects, and strong ethical character during key transition years.',
    keyHighlights: ['Design thinking workshops', 'Robotics & computational logic', 'Advisory mentorship circles'],
    image: leadershipImg,
  },
  {
    id: 'senior-school',
    title: 'Senior School',
    subtitle: 'Grades 9 through 10',
    ageRange: 'Ages 14 – 15',
    curriculum: 'Rigorous International Diplomas & IGCSE',
    description: 'Fostering deep subject mastery, research competence, laboratory sciences, and global issues debate designed to challenge and inspire ambitious learners.',
    keyHighlights: ['Advanced laboratory sciences', 'Global perspectives seminar', 'Civic leadership portfolio'],
    image: scienceLabImg,
  },
  {
    id: 'pre-university',
    title: 'Pre-University & Diploma',
    subtitle: 'Grades 11 through 12',
    ageRange: 'Ages 16 – 18',
    curriculum: 'International Baccalaureate (IB DP) & AP Honors',
    description: 'A pre-eminent preparatory program developing university-ready research, extended essay scholarship, theory of knowledge, and world-class admissions readiness.',
    keyHighlights: ['Dedicated university counseling', 'Extended research theses', '100% tertiary placement rate'],
    image: libraryImg,
  },
];

export const WHY_NOVA_CREST = [
  {
    number: '01',
    title: 'Future-Ready Curriculum',
    description: 'Bridging timeless intellectual rigor with AI literacy, bioinformatics, and interdisciplinary problem-solving designed for a rapidly evolving global landscape.',
  },
  {
    number: '02',
    title: 'Personalised Learning Pathways',
    description: 'Small class cohorts and dedicated academic advisors ensure each student’s unique talents, pace, and passions are recognized, challenged, and nurtured.',
  },
  {
    number: '03',
    title: 'Deep Global Perspective',
    description: 'With over 40 nationalities represented across our campus community, students cultivate genuine cultural empathy, multilingual fluency, and world citizenship.',
  },
  {
    number: '04',
    title: 'Character & Ethical Leadership',
    description: 'Academic distinction is grounded in integrity, empathy, and active stewardship. Our students learn that true leadership means serving others with purpose.',
  },
  {
    number: '05',
    title: 'Arts, Sport & Creative Mastery',
    description: 'Exceptional facilities in performance, studio art, competitive athletics, and design encourage students to balance intellectual study with expressive passion.',
  },
  {
    number: '06',
    title: 'Safe & Supportive Community',
    description: 'A 24-acre parkland campus featuring dedicated health suites, positive psychology pastoral care, and a warm family-centered culture where every learner belongs.',
  },
];

export const CAMPUS_ACTIVITIES: Activity[] = [
  {
    id: 'act-1',
    category: 'Athletics',
    title: 'Competitive Varsity Sports & Aquatics',
    description: 'Championship training across soccer, basketball, swimming, track and field, and tennis led by certified performance coaches.',
    image: athleticsImg,
    highlight: '14 Regional Titles',
  },
  {
    id: 'act-2',
    category: 'Performing Arts',
    title: 'Symphonic Orchestra & Theater Arts',
    description: 'Annual full-scale theatrical productions, jazz ensembles, and choral performances in our 650-seat acoustically engineered auditorium.',
    image: performingArtsImg,
    highlight: '650-Seat Auditorium',
  },
  {
    id: 'act-3',
    category: 'Leadership',
    title: 'Model United Nations & Parliamentary Debate',
    description: 'Honing public rhetoric, international diplomacy, and legislative analysis at international conferences across North America and Europe.',
    image: leadershipImg,
    highlight: 'International Delegation',
  },
  {
    id: 'act-4',
    category: 'Visual Arts',
    title: 'Fine Arts, Ceramics & Digital Media',
    description: 'Sunlit studio spaces equipped with printmaking presses, pottery kilns, photography darkrooms, and high-spec animation workstations.',
    image: visualArtsImg,
    highlight: 'Annual Spring Biennale',
  },
  {
    id: 'act-5',
    category: 'Clubs',
    title: 'Robotics Engineering & Quantum STEM Club',
    description: 'Autonomous robotics, drone aerial mechanics, and competitive coding leagues solving real-world humanitarian engineering challenges.',
    image: scienceLabImg,
    highlight: 'FIRST Robotics Regional Finalists',
  },
  {
    id: 'act-6',
    category: 'Community',
    title: 'Ecological Stewardship & Outreach Projects',
    description: 'Student-led community gardens, local literacy initiatives, and partnerships with environmental conservation NGOs.',
    image: campusArchImg,
    highlight: '20,000+ Annual Service Hours',
  },
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 'test-1',
    quote: 'Nova Crest has given our daughter the quiet confidence to ask courageous questions, embrace challenging subjects, and genuinely love learning every single morning. The faculty sees who she is and champions her potential.',
    parentName: 'Eleanor & Marcus Vance',
    relation: 'Parents of Chloe',
    studentGrade: 'Grade 10 Scholar',
    initials: 'EV',
    rating: 5,
  },
  {
    id: 'test-2',
    quote: 'Relocating internationally can be daunting for any family, but Nova Crest welcomed our sons with open arms. Within weeks, they were thriving academically and playing in the symphonic ensemble. The warmth here is extraordinary.',
    parentName: 'Dr. Tariq & Amina Al-Mansoor',
    relation: 'Parents of Zayd and Rayan',
    studentGrade: 'Grades 6 & 11',
    initials: 'TA',
    rating: 5,
  },
  {
    id: 'test-3',
    quote: 'The balance between academic rigor and character development is unmatched. Our son was admitted to his first-choice university with an honors scholarship, fully prepared for independent research and purposeful living.',
    parentName: 'Sarah Jenkins, Esq.',
    relation: 'Mother of Julian',
    studentGrade: 'Class of 2025 Alumnus',
    initials: 'SJ',
    rating: 5,
  },
];

export const NEWS_ARTICLES: NewsArticle[] = [
  {
    id: 'news-1',
    title: 'Senior Class Celebrates 100% Ivy League and Russell Group Offers',
    date: 'March 28, 2026',
    category: 'Academic Honors',
    readTime: '4 min read',
    excerpt: 'Nova Crest seniors receive early admissions to Oxford, Stanford, MIT, Cambridge, and Yale with over $3.2M in merit academic scholarships.',
    image: libraryImg,
    content: 'We are thrilled to celebrate the exceptional scholarly accomplishments of our graduating Class of 2026. Through disciplined inquiry, rigorous preparation in the International Baccalaureate and AP frameworks, and dedicated university advisory mentorship, our seniors continue Nova Crest’s 15-year legacy of global tertiary placement excellence.',
  },
  {
    id: 'news-2',
    title: 'Students Unveil Campus Solar Pavilion & Zero-Waste Sustainability Charter',
    date: 'March 15, 2026',
    category: 'Campus Stewardship',
    readTime: '3 min read',
    excerpt: 'A student-designed solar pavilion and closed-loop composting facility now powers our upper campus science complex.',
    image: campusArchImg,
    content: 'Spearheaded by the Middle and Senior School Eco-Council, Nova Crest officially launched its 2030 Net-Zero Campus Charter this week. The initiative demonstrates how interdisciplinary engineering, civic responsibility, and environmental sciences coalesce into tangible improvements on our 24-acre grounds.',
  },
  {
    id: 'news-3',
    title: 'Annual Fine Arts and Innovation Showcase Opens to the Community',
    date: 'February 22, 2026',
    category: 'Arts & Culture',
    readTime: '5 min read',
    excerpt: 'Over 200 student works spanning oil painting, architectural scale models, digital cinematography, and musical compositions presented to families.',
    image: visualArtsImg,
    content: 'Our annual arts gala returned with breathtaking creativity. From primary students presenting interactive ceramic sculptures to senior IB visual arts portfolios exploring human resilience, the exhibition celebrated the expansive imagination fostered daily across all grades.',
  },
];
