/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { Introduction } from './components/Introduction';
import { StatsSection } from './components/StatsSection';
import { AcademicPrograms } from './components/AcademicPrograms';
import { WhyNovaCrest } from './components/WhyNovaCrest';
import { BurgundyStatsBand } from './components/BurgundyStatsBand';
import { CampusLife } from './components/CampusLife';
import { CampusExperience } from './components/CampusExperience';
import { Testimonials } from './components/Testimonials';
import { NewsSection } from './components/NewsSection';
import { AdmissionsCTA } from './components/AdmissionsCTA';
import { EnquiryForm } from './components/EnquiryForm';
import { Footer } from './components/Footer';
import { SearchModal } from './components/SearchModal';
import { VirtualTourModal } from './components/VirtualTourModal';
import { BackToTop } from './components/BackToTop';

export default function App() {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isVirtualTourOpen, setIsVirtualTourOpen] = useState(false);

  const scrollToSection = (id: string) => {
    const el = document.querySelector(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleBookTour = () => {
    scrollToSection('#tour-enquiry');
  };

  const handleExploreAdmissions = () => {
    scrollToSection('#admissions');
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF8F3] text-[#242424] antialiased">
      {/* 1 & 2. Global Two-Level Header (Utility Bar + Main Sticky Navigation) */}
      <Header
        onOpenSearch={() => setIsSearchOpen(true)}
        onBookTourClick={handleBookTour}
      />

      <main className="flex-1">
        {/* 3. Hero Section */}
        <Hero
          onExploreAdmissions={handleExploreAdmissions}
          onOpenVirtualTour={() => setIsVirtualTourOpen(true)}
        />

        {/* 4. Introduction / School Story Section */}
        <Introduction />

        {/* 5. Trust / Statistics Section */}
        <StatsSection />

        {/* 6. Academic Programs Pathways */}
        <AcademicPrograms />

        {/* 7. Why Nova Crest / Signature Strengths */}
        <WhyNovaCrest />

        {/* 8. Full-Width Deep Burgundy Statistics Band */}
        <BurgundyStatsBand />

        {/* 9. Campus Life / Beyond the Classroom Activities */}
        <CampusLife />

        {/* 10. Campus Experience Split-Screen Section */}
        <CampusExperience
          onExploreCampus={() => setIsVirtualTourOpen(true)}
        />

        {/* 11. Parent & Family Testimonials */}
        <Testimonials />

        {/* 12. News & Campus Journal */}
        <NewsSection />

        {/* 13. Admissions High-Conversion CTA Band */}
        <AdmissionsCTA
          onStartApplication={() => scrollToSection('#tour-enquiry')}
          onBookCampusTour={handleBookTour}
        />

        {/* 14. Campus Tour / Enquiry Panel Form */}
        <EnquiryForm />
      </main>

      {/* 15. Deep Burgundy Institutional Footer */}
      <Footer />

      {/* Interactive Global Modals & Controls */}
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onNavigate={(href) => scrollToSection(href)}
      />

      <VirtualTourModal
        isOpen={isVirtualTourOpen}
        onClose={() => setIsVirtualTourOpen(false)}
        onBookLiveTour={handleBookTour}
      />

      <BackToTop />
    </div>
  );
}
