export interface Program {
  id: string;
  title: string;
  subtitle: string;
  ageRange: string;
  description: string;
  keyHighlights: string[];
  image: string;
  curriculum: string;
}

export interface Activity {
  id: string;
  category: 'Athletics' | 'Performing Arts' | 'Visual Arts' | 'Leadership' | 'Community' | 'Clubs';
  title: string;
  description: string;
  image: string;
  highlight: string;
}

export interface Testimonial {
  id: string;
  quote: string;
  parentName: string;
  relation: string;
  studentGrade: string;
  initials: string;
  rating: number;
}

export interface NewsArticle {
  id: string;
  title: string;
  date: string;
  category: string;
  excerpt: string;
  readTime: string;
  image: string;
  content: string;
}

export interface EnquirySubmission {
  parentName: string;
  email: string;
  phone: string;
  studentName: string;
  currentGrade: string;
  applyingGrade: string;
  preferredVisitDate: string;
  visitSession: string;
  message: string;
}
