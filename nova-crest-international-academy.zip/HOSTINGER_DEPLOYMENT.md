# How to Deploy Nova Crest International Academy on Hostinger

This project is built with React, Vite, and Tailwind CSS. It builds into pure static assets (`dist/`), making it 100% compatible with Hostinger Web Hosting, Cloud Hosting, and WordPress Hosting plans.

---

## Method 1: Hostinger File Manager (Quickest — 2 Minutes)

This is the fastest and easiest method using Hostinger's **hPanel**.

### Step 1: Build the Production Bundle
If you have the project on your local machine:
```bash
npm install
npm run build
```
*(A pre-built `dist/` and `dist.zip` are already generated in the project root)*

### Step 2: Upload to Hostinger
1. Log in to your [Hostinger hPanel](https://hpanel.hostinger.com/).
2. Go to **Websites** → Select your domain → Click **Manage**.
3. Under the **Files** section, click **File Manager** (Access files of your website).
4. Double-click to open the `public_html` directory.
5. If there is a default `default.php` or `index.php` placeholder from Hostinger, you can delete or backup it.
6. Click the **Upload** icon (top right) → Choose **File** → Select `dist.zip`.
7. Once uploaded, right-click `dist.zip` and select **Extract**.
8. Extract files directly into `public_html`.
   - *Ensure the files (`index.html`, `.htaccess`, `robots.txt`, and the `assets/` folder) are directly inside `public_html`, not inside a nested subfolder.*
9. Delete `dist.zip`.

### Step 3: Test Your Website
Visit `https://yourdomain.com` in your browser. Your school website is now live!

---

## Method 2: Hostinger Git Deployment (Continuous Deployment)

If your project is pushed to a GitHub or GitLab repository:

1. In Hostinger **hPanel**, navigate to **Advanced** → **GIT**.
2. Enter your repository URL (e.g., `https://github.com/your-username/nova-crest-school.git`).
3. Select branch: `main`.
4. Install Directory: leave blank or set to `/public_html`.
5. Click **Create**.
6. If building on the server, you can configure an automated deployment script or build action, or deploy the built `dist` branch.

---

## Method 3: Upload via FTP (FileZilla)

1. In Hostinger **hPanel**, go to **Files** → **FTP Accounts**.
2. Note your **FTP Host**, **FTP Username**, **FTP Password**, and **Port** (usually `21`).
3. Open FileZilla (or your preferred FTP client) and connect.
4. On the remote server side, enter the `public_html` directory.
5. On the local computer side, open the `dist` folder.
6. Drag and drop all contents of `dist/`:
   - `index.html`
   - `.htaccess`
   - `robots.txt`
   - `assets/`
7. Wait for all files to upload.

---

## Key Included Configurations

- **`.htaccess`**:
  - Automatically redirects HTTP traffic to secure HTTPS.
  - Handles Single Page Application (SPA) URL rewrites so subpaths don't return 404 errors.
  - Enables Gzip/Brotli compression for rapid page loads.
  - Implements browser cache expiry headers (1 year for CSS, JS, and image assets).
  - Configures standard security headers (`X-Frame-Options`, `X-Content-Type-Options`).
- **`robots.txt`**: Ready for search engine indexing.
